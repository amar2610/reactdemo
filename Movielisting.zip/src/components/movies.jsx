import { useDispatch, useSelector } from "react-redux";
import { like, unlike } from "../app/slice/likeslice"; 

const MovieData = ({ data }) => {
  const dispatch = useDispatch();

  const likedMovies = useSelector((state) => state.liked.value);
  const isFavorite = likedMovies.some((movie) => movie.id === data.id);

  const toggleFavorite = () => {
    if (isFavorite) {
      dispatch(unlike({ id: data.id }));
    } else {
      dispatch(like(data)); 
    }
  };

  return (
    <div
      key={data.id}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 p-4 h-100 relative flex flex-col"
    >
      <button
        onClick={toggleFavorite}
        className={`absolute top-3 right-3 text-xl transition ${
          isFavorite ? "text-red-500" : "text-gray-300 hover:text-red-400"
        }`}
        title="Favorite"
      > {isFavorite ? <div> ❤️</div>:<div> 🤍</div>}
        
      </button>

      <img
        src={data.poster}
        alt={data.imageAlt || data.title}
        className="w-full h-60 object-cover rounded-md mb-4"
      />

      <div className="flex-grow flex flex-col justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">
            {data.title}{" "}
            <span className="text-sm text-gray-500">({data.year})</span>
          </h3>
          <p className="text-sm text-gray-600 mt-1">{data.genre?.join(", ")}</p>
          <p className="text-sm text-gray-700 mt-2 line-clamp-3">{data.plot}</p>
        </div>
        <div className="mt-4 flex justify-between items-center text-sm text-gray-500">
          <span className="flex items-center gap-1">
            ⭐ <span className="font-medium text-yellow-600">{data.rating}</span>
          </span>
          <span className="text-xs">🎬 {data.director}</span>
        </div>
      </div>
    </div>
  );
};

export default MovieData;
