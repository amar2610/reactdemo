import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import MovieData from './movies';
import { DNA } from 'react-loader-spinner'
import NavBar from './navbar';
import { useEffect } from "react";



export default function MovieCard() {
  const data = useSelector((state) => state.movies.value);
  const [products, setData] = useState(data);
  const [loader, setLoader] = useState(true);

  useEffect(() => {
    setData(data);
  }, [data]);

  useEffect(() => {
    setTimeout(() => {
      setLoader(false);
    }, 3000)

  }, [])

  const handleChange = (e) => {
    const value = e;

    if (value === "") {
      setData(data);
    } else { 
      const filtered = data.filter((movie) =>
        movie.title.toLowerCase().includes(value.toLowerCase())
      );
      setData(filtered);
    }
  };

  const handlecategory = (e) => {
    const value = e;
    console.log(value);
    if (value === "") {
      setData(data);
    } else {
      const filtered = data.filter((movie) =>
        movie.genre.some((g) =>
          g.toLowerCase().includes(value.toLowerCase())
        )
      );
      setData(filtered);
    }
  };


  return (
    <>
      {loader ?

        <center style={{ marginTop: '350px' }}>
          <DNA
          visible={true}
          height="200"
          width="300"
          ariaLabel="dna-loading"
          wrapperStyle={{}}
          wrapperClass="dna-wrapper"
        /></center>


        :


        <div> <NavBar />
          <div className="flex flex-row gap-2">
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm transition duration-300"
              onClick={(() => {
                handlecategory('')
              })}
            >
              All
            </button>
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm transition duration-300"
              onClick={(() => {
                handlecategory('action')
              })}
            >
              Action
            </button>
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm transition duration-300"
              onClick={(() => {
                handlecategory('drama')
              })}
            >
              Drama
            </button>
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm transition duration-300"
              onClick={(() => {
                handlecategory('comedy')
              })}
            >
              Comedy
            </button>
          </div>

          <div className="bg-gray-100 min-h-screen py-10">
            <div className="ml-auto mt-2">
              <div className="flex items-center rounded-md bg-white pl-3 outline outline-1 outline-gray-300 focus-within:outline-2 focus-within:outline-indigo-600">
                <input
                  id="search"
                  name="search"
                  onChange={(e) => { handleChange(e.target.value) }}
                  type="text"
                  placeholder="Search movies..."
                  className="block w-full py-2 pr-4 pl-3 text-base text-gray-900 placeholder:text-gray-400 focus:outline-none sm:text-sm"
                />
              </div>
            </div>
            <div className="max-w-7xl mx-auto px-4">
              <h2 className="text-3xl font-bold text-gray-800 mb-10">🎬 Recommended Movies</h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">



                {products.length === 0 ? (
                  <p className="text-gray-500 col-span-full text-center">No movies found.</p>
                ) : (
                  products.map((product) => (
                    <MovieData data={product} />
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      }
    </>
  );
}
