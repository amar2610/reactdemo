import React from 'react';
import { useSelector } from 'react-redux';
import MovieData from './movies';
import NavBar from './navbar';


export default function LikedMovies() {
  const products = useSelector((state) => state.liked.value);
  return (
    <div> <NavBar />
      <div className="bg-gray-100 min-h-screen py-10">

        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-800 mb-10">🎬 Recommended Movies</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.length === 0 ? (
              <p className="text-gray-500 col-span-full text-center">No movies found.</p>
            ) : (
              products.map((product) => (
                <MovieData data={product} />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
