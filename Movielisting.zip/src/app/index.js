import { configureStore } from "@reduxjs/toolkit";
import MovieSlice from'../app/slice/movieslice';
import LikeSlice from '../app/slice/likeslice';
export  const store =configureStore(
    {
    reducer:{
         movies: MovieSlice,
         liked:LikeSlice
    }
})