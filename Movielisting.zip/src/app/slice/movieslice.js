import{ createSlice }from "@reduxjs/toolkit";
import movie from '../../data/moviesjson.json';

const MovieSlice=createSlice({
        name: 'Movies',
        initialState:{value: movie}
});
export default MovieSlice.reducer;