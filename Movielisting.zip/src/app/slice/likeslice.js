import { createSlice } from '@reduxjs/toolkit';

const LikeSlice = createSlice({
  name: 'liked',
  initialState: {
    value: [] 
  },
  reducers: {
    like: (state, action) => {        
      state.value.push(action.payload);
    },
    unlike: (state, action) => {
      state.value = state.value.filter(movie => movie.id !== action.payload.id);
    }
  }
});

export const { like, unlike } = LikeSlice.actions;
export default LikeSlice.reducer;
