import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LikedMovies from './components/likedmovies';
import MovieCard from './components/moviecard';
import NavBar from './components/navbar';

function App() {
  return (
    <Router>
    <Routes>
      <Route path="/" element={<MovieCard />} />
      <Route path="/liked" element={<LikedMovies />} />
    </Routes>
  </Router>
  );
}

export default App;
