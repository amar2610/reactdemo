import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/homepage';
import Login from './pages/login';
import { AutheProvider } from './context/AuthContext';
import Dasboard from './pages/dasboard';
import Privateroutes from './components/PrivateRoutes';
function App() {
  return (
    <AutheProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage/>} />
          <Route path="/login" element={< Login/>} />
          <Route path="/desboard" element={<Privateroutes><Dasboard/></Privateroutes>} />
         
        </Routes>
      </Router>
    </AutheProvider>
    
  );
}

export default App;
