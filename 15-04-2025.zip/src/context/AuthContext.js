import { createContext, useContext, useState } from 'react'
const AutheContext = createContext();

export const AutheProvider = ({ children }) => {
    let toekn = localStorage.getItem("username");
    let userdata = null
    if (toekn) {
        userdata = toekn
    }
    const [user, setuser] = useState(userdata);
    console.log(user);

    const login = (userdata) => {
        setuser(userdata);
    }
    const logout = () => {
        setuser(null);

    }
    return (
        <AutheContext.Provider value={{ user, login, logout }}>
            {children}
        </AutheContext.Provider>
    );
}
export const UserAuth = () => useContext(AutheContext);