import NavBar from "../components/naviagtionbar";
const Dasboard = () => {
        return (
                <> <NavBar />
                <div className="container">
                <div className="styles.card">
                    <div className="styles.header">
                        <img
                            src="https://tse2.mm.bing.net/th?id=OIP.YoTUWMoKovQT0gCYOYMwzwHaHa&pid=Api&P=0&h=180"
                            alt="User Avatar"
                            className="avtar"
                        />
                        <div>
                            <h2 className="name">Jane Doe</h2>
                            <p className="role">Software Developer</p>
                        </div>
                    </div>
                    <div className="details">
                        <p><strong>Email:</strong> jane.doe@example.com</p>
                        <p><strong>Phone:</strong> +1 234 567 8901</p>
                        <p><strong>Location:</strong> New York, USA</p>
                    </div>
                </div>
            </div>
                </>
               
                
                
               
        );
}
export default Dasboard