import { UserAuth } from "../context/AuthContext";
import{useNavigate} from "react-router-dom";
import axios from 'axios';
import { ColorRing } from 'react-loader-spinner'
import { useState } from "react";

const Login=()=>{
    const [loader,setloader]=useState(false);
        const{login} =UserAuth();
        const Navigate=useNavigate();
        
        
    
        const  handleLogin= async()=>{
          setloader(true)
            setTimeout( async()=>{
              try{
              let email=document.getElementById('email').value;
              let password=document.getElementById('password').value
                const api= await axios.post("https://reqres.in/api/login",{email:email,
                    password:password});
                 
                  
                      localStorage.setItem('username',api.data.token);

                      login({username:'Amar'});
                      Navigate('/desboard');
                    }
                    catch(error){
                      alert("user not found");
                      Navigate('/login');
                    }
              
                setloader(false)
            },3000)
           
        }
        return(
            <div className="login-container">
            <div className="login-box">
              <h2>Login</h2>
              <input type="text" id='email' placeholder="Username" className="login-input"  required/>
              <input type="password" id='password' placeholder="Password" className="login-input" required />
              <button onClick={handleLogin} className="login-button">{
                loader ?    ( <ColorRing
                  visible={true}
                 
                  ariaLabel="color-ring-loading"
                
                  wrapperClass="color-ring-wrapper"
                  colors={['#e15b64', '#f47e60', '#f8b26a', '#abbd81', '#849b87']}
                  />) : 'Login'
                }
             </button>
            </div>
          </div>
        );
}
export default Login