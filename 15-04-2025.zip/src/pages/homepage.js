import { Link } from "react-router-dom"
import NavBar from "../components/naviagtionbar";
const HomePage=()=>{
    return (
        <div>
            <NavBar/>
        </div>
    )
}
export default HomePage