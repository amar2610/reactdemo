import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

const NavBar = () => {
  const navigate = useNavigate();
  const [log, setLog] = useState(localStorage.getItem("username"));

  // ✅ Check login status when component mounts or localStorage changes
  useEffect(() => {
    const username = localStorage.getItem("username");
    setLog(username);
  }, []);

  const handleLogin = () => {
    navigate('/login');
  };

  const handleLogout = () => {
    localStorage.removeItem("username");
    setLog(null);
    navigate('/');
  };

  return (
    <nav className="dashboard-navbar">
      <div className="navbar-logo">
        <h2>User Panel</h2>
      </div>
      <ul className="navbar-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/">About</Link></li>
        {log && <li><Link to="/desboard">Dashboard</Link></li>}
      </ul>
      <div className="navbar-user">
        {!log
          ? <button className="logout-btn" onClick={handleLogin}>Login</button>
          : <button className="logout-btn" onClick={handleLogout}>Logout</button>
        }
      </div>
    </nav>
  );
};

export default NavBar;
