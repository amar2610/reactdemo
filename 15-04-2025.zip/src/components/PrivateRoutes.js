import {Navigate} from'react-router-dom';
import { UserAuth } from '../context/AuthContext';

const Privateroutes =({children})=>{
    const{user}=UserAuth();
     
    return user ? children :<Navigate to={'/login'}/>

};
export default Privateroutes;