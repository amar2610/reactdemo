import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const Desboard = () => {
    const Navigate=useNavigate();
        const user = useSelector((state) => state.Users.value);
        const Product = useSelector((state) => state.Products.value);
        const Category = useSelector((state) => state.Category.value);
        const adminLogout=()=>{
            
            localStorage.removeItem("username");
                Navigate('/login');
        }
    
    return (
        <div>
            <div className="d-flex">
                <div className="sidebar p-3">
                    <h4 className="text-white">Admin Panel</h4>
                    <a href="#">Dashboard</a>
                    <button type="submit" onClick={adminLogout} >LogOut</button>
                </div>
                <div className="main w-100">
                    <nav className="navbar navbar-expand-lg navbar-light bg-light px-4">
                        <span className="navbar-brand">Admin Dashboard</span>
                    </nav>
                    <div className="row my-4">
                        <div className="col-md-4">
                            <div className="card text-white bg-primary mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">Total Products</h5>
                                    <p className="card-text" id="total-order">{Product.length}</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="card text-white bg-primary mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">Total users</h5>
                                    <p className="card-text" id="total-order">{user.length}</p>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4">
                            <div className="card text-white bg-primary mb-3">
                                <div className="card-body">
                                    <h5 className="card-title">Total Categories</h5>
                                    <p className="card-text" id="total-user">{Category.length}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}
export default Desboard