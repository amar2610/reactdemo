import React, { useState } from 'react';
import { useFormik } from 'formik';
import{useNavigate} from "react-router-dom";
import { UserAuth } from "../context/AuthContext";
import axios from 'axios';

import { ColorRing } from 'react-loader-spinner'
import * as Yup from 'yup';
function Login() {
    const [loading, setLoading] = useState(false);
    const [userdata, setUserData] = useState({});
   
 
    const myFunction = () => {

        let x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    };
    const{login} =UserAuth();
        const Navigate=useNavigate();
    const formik = useFormik({
        initialValues: {
            email: '',
            password: '',
           
        },
      
        validationSchema: Yup.object({
        
            email: Yup.string().trim().email("Enter a valid email").required("Email is required"),
            password: Yup.string().required('Password Is Required'),
        }),
        
        onSubmit: async () => {
            setLoading(true)
            setTimeout( async()=>{
              try{
              let email=formik.values.email;
              let password=formik.values.password;
              console.log(email,password);
              
                const api= await axios.post("https://api.escuelajs.co/api/v1/auth/login",{email:email,
                    password:password});
                 console.log(api.data);
                 
                      localStorage.setItem('username',api.data.access_token);

                      login({username:'Amar'});
                      Navigate('/desboard');
                    }
                    catch(error){
                      alert("user not found");
                      Navigate('/login');
                    }
              
                    setLoading(false)
            },3000)
        }
           
    });

    return (
        <div className=''>
        <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 bg-white dark:bg-gray-900 text-black dark:text-white">
           
                
                <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">
                    <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Login Page</h2>
                    <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>

                      
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Email</label>
                            <input
                                type="email"
                                name="email"
                                placeholder="Your Email"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.email}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.email && formik.errors.email && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.email}</div>
                            )}
                        </div>
                     


                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Password</label>
                            <input
                                type="password"
                                name="password"
                                id="password"
                                placeholder="Your password"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.password}
                                onChange={(e) => { formik.handleChange(e) }}
                                onBlur={formik.handleBlur}
                            /><button id="togglePassword" type="button" className="absolute   px-1 py-3 text-blue-600 hover:text-blue-600" onClick={myFunction}>👁️</button>

                            {formik.touched.password && formik.errors.password && (
                                <div className="text-rose-700">{formik.errors.password}</div>
                            )}
                        </div>
                        <div>

                        </div>

                      




                        <button
                            type="submit"
                            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800 disabled:bg-blue-200 disabled:cursor-not-allowed"
                            disabled={!formik.dirty || !formik.isValid}
                        >
                            {loading ? (<center> <ColorRing
                                visible={true}
                                height="40"
                                width="90"
                                ariaLabel="color-ring-loading"
                                wrapperStyle={{}}
                                wrapperClass="color-ring-wrapper"
                                colors={['#fff', '#fff', '#fff', '#fff', '#fff']}
                            /></center>) : "Login"}
                        </button>

                    </form>
                </div>
                 
        </div>
        </div>
    );
}

export default Login;
