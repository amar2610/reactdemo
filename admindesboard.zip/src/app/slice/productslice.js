import{ createSlice }from "@reduxjs/toolkit";
import axios from "axios";
const product = await axios.get('https://api.escuelajs.co/api/v1/products');
const data=product.data    

const ProductSlice=createSlice({
        name: 'Products',
        initialState:{value: data},
        reducers: {
            update: (state, action) => {    
            state.value = state.value.filter(product => product.id !== action.payload.id);    
              state.value.push(action.payload);
            },
            delet: (state, action) => {
              
              state.value = state.value.filter(product => product.id !== action.payload.id);  
            }
          }
});
export const { update , delet } = ProductSlice.actions;
export default ProductSlice.reducer;