import{ createSlice }from "@reduxjs/toolkit";
import axios from "axios";
const user = await axios.get('https://api.escuelajs.co/api/v1/categories');
const data=user.data    

const CategorySlice=createSlice({
        name: 'Category',
        initialState:{value: data},
        reducers: {
            update: (state, action) => {    
            state.value = state.value.filter(movie => movie.id !== action.payload.id);    
              state.value.push(action.payload);
            },
            delet: (state, action) => {
              
              state.value = state.value.filter(product => product.id !== action.payload.id);  
            }
          }
});
export const { update , delet } = CategorySlice.actions;

export default CategorySlice.reducer;