import{ createSlice }from "@reduxjs/toolkit";
import axios from "axios";
const user = await axios.get('https://api.escuelajs.co/api/v1/users?limit=20');
const data=user.data    

const UserSlice=createSlice({
        name: 'Users',
        initialState:{value: data},
        reducers: {
            update: (state, action) => {    
            state.value = state.value.filter(movie => movie.id !== action.payload.id);    
              state.value.push(action.payload);
            },
            delet: (state, action) => {
              
              state.value = state.value.filter(user => user.id !== action.payload.id);  
              console.log(state.value);
              
            }
          }
});
export const { update , delet } = UserSlice.actions;

export default UserSlice.reducer;