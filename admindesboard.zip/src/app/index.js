import { configureStore } from "@reduxjs/toolkit";
import ProductSlice  from './slice/productslice';
import UserSlice from './slice/userslice';
import CategorySlice from './slice/categoryslice'
export  const store =configureStore(
    {
    reducer:{
         Products: ProductSlice,
         Users:  UserSlice,
         Category:CategorySlice
    }
})