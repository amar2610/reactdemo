import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/login';
import { AutheProvider } from './context/AuthContext';
import Privateroutes from './components/PrivateRoutes';
import Desboard from './pages/desboard';
import Products from './components/Products';
import  {store} from './app/index';
import {Provider} from 'react-redux';
import Users from './components/user';
import Category from './components/category';
import CreateProduct from './components/createProduct';
import ProductDetails from './components/productdetails';
import CreateCategory from './components/addCategory';
import UpdateProduct from './components/updateProduct';
import UpdateCategory from './components/updateCategory';
function App() {
  return (
    <Provider store={store}>
    <AutheProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Privateroutes><Products/></Privateroutes>} />
          <Route path="/user" element={<Privateroutes><Users/></Privateroutes>} />
          <Route path='/category' element={<Privateroutes><Category/></Privateroutes>}/>
          <Route path="/login" element={< Login/>} />
          <Route path="/addproduct" element={<Privateroutes>< CreateProduct/></Privateroutes>} />
          <Route path="/productdetail/:proId" element={<Privateroutes> < ProductDetails/></Privateroutes>} />
          <Route path="/desboard" element={<Privateroutes><Desboard/></Privateroutes>} />
          <Route path="/addcategory" element={<Privateroutes><CreateCategory/></Privateroutes>} />
          <Route path="/updateproduct/:proId" element={<Privateroutes><UpdateProduct/></Privateroutes>} />
          <Route path="/updatecategory/:proId" element={<Privateroutes><UpdateCategory/></Privateroutes>} />




         
        </Routes>
      </Router>
    </AutheProvider>
    </Provider>
    
  );
}

export default App;