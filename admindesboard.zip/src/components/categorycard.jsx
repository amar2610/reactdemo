import React from 'react';
import { useDispatch } from 'react-redux';
import { delet } from '../app/slice/categoryslice';
import { Link } from 'react-router-dom';

const CategoryCard = (props) => {
    console.log("second data", props);
    const dispatch = useDispatch();
    const Delete = () => {        
          dispatch(delet({ id: props.pg.id}));
      };
    return (
        <div className="col-md-4 mb-4">
            <div className="card h-100 shadow-sm">
                <img src={props.pg.image} className="card-img-top" alt={props.pg.name} style={{ height: '250px', objectFit: 'cover' }} />
                <div className="card-body">
                    <h5 className="card-title">{props.pg.name}</h5>
                    <p className="text-muted"><strong>Slug:</strong> {props.pg.slug}</p>
                    <button   type='button' className="btn btn-primary mt-2" onClick={Delete}>delete</button>
                    <Link to={`/updatecategory/${props.pg.id}`} className="btn btn-primary mt-2">update</Link>

                    </div>
            </div>
        </div>
    );
};

export default CategoryCard;
