import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { useDispatch,useSelector } from 'react-redux';
import { update,delet } from '../app/slice/productslice';


const ProductDetails = () => {
    

    const {proId} = useParams();
    
    let datas = useSelector((state) => state.Products.value);
    
  let  data= datas.filter(Product => Product.id == proId );  
  
  
  
   

    return (
        <div className="col-md-4 m-8 ...">
            <form >
            <div className="card h-100 shadow-sm">
                <img src={data[0].images[0]} className="card-img-top" alt={data[0].title} style={{  objectFit: 'fill' }} />
                <div className="card-body">
                    <h5 className="card-title">{data[0].title}</h5>
                    <p className="text-muted"><strong>Slug:</strong> {data[0].slug}</p>
                    <p className="text-muted"><strong>Description:</strong> {data[0].description}</p>
                    <p className="text-muted"><strong>Price:</strong> {data[0].price}</p>
                </div>
            </div>
            </form>
        </div>
    );
};

export default ProductDetails;
