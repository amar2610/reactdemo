import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import CategoryCard from './categorycard';
const Category = () => {
  const [pgs, setPgs] = useState([]);
  const data = useSelector((state) => state.Category.value);


  useEffect(() => {
   setPgs(data) 
  }, [data]);

  return (
    <div className="container mt-4">
        
      <div className="row">
        {pgs.map((pg) => (
          <CategoryCard  pg={pg} />
        ))}
      </div>
    </div>
  );
};

export default Category;
