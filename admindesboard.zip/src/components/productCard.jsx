import React from 'react';
import { Link } from 'react-router-dom';
import { useDispatch,useSelector } from 'react-redux';
import { update,delet } from '../app/slice/productslice';

const ProductCard = (props) => {

   const dispatch = useDispatch();
    const Delete = () => {        
          dispatch(delet({ id: props.pg.id}));
      };
      
    
  return (
    <div className="col-md-4 mb-4">
      <div className="card h-100 shadow-sm">
        <img src={props.pg.images[0]} className="card-img-top" alt={props.pg.title} style={ {height: '250px', objectFit: 'cover' }} />
        <div className="card-body">
          <h5 className="card-title">{props.pg.title}</h5>
          <p className="text-muted"><strong>Category:</strong> {props.pg.category.name}</p>
          <p><strong>Price:</strong> ₹{props.pg.price}</p>
          <p className="card-text">{props.pg.description}...</p>
          <Link to={`/productdetail/${props.pg.id}`} className="btn btn-primary mt-2">productdetails Now</Link>
          <button   type='button' className="btn btn-primary mt-2" onClick={Delete}>delete</button>
          <Link to={`/updateproduct/${props.pg.id}`} className="btn btn-primary mt-2">update</Link>


        </div>
      </div>
    </div>
  );
};

export default ProductCard;
