import React, { useState } from 'react';
import { useFormik } from 'formik';
import { useNavigate } from "react-router-dom";
import axios from 'axios';

import { ColorRing } from 'react-loader-spinner'
import * as Yup from 'yup';
function CreateCategory() {

    const [loading, setLoading] = useState(false);
    const Navigate = useNavigate();

    const formik = useFormik({
        initialValues: {
            name: '',
            image: '',
        },

        validationSchema: Yup.object({

            name: Yup.string().required("name is required"),
           
            image: Yup.string().required('image Is Required'),


        }),

        onSubmit: async () => {
            setLoading(true)
            setTimeout(async () => {
                try {
                 

                   
                    let produdetails = {
                        name: formik.values.name,
                        image: formik.values.image
                    }

                    const api = await axios.post("https://api.escuelajs.co/api/v1/categories", produdetails);
                    console.log(api.data);
                    Navigate('/category');
                }
                catch (error) {
                    console.log(error);

                    Navigate('/addcategory');
                }

                setLoading(false)
            }, 3000)
        }

    });

    return (
        <div >
            <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 bg-white dark:bg-gray-900 text-black dark:text-white">


                <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">
                    <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Add Product</h2>
                    <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Name</label>
                            <input
                                type="text"
                                name="name"
                                placeholder="Your name"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.name}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.name && formik.errors.name && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.name}</div>
                            )}
                        </div>
                       
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Images</label>
                            <input
                                type="text"
                                name="image"
                                placeholder="Your images"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.image}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.image && formik.errors.image && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.image}</div>
                            )}
                        </div>

                       
                        <div>
                        </div>
                        <button
                            type="submit"
                            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800 disabled:bg-blue-200 disabled:cursor-not-allowed"
                            disabled={!formik.dirty || !formik.isValid}
                        >
                            {loading ? (<center> <ColorRing
                                visible={true}
                                height="40"
                                width="90"
                                ariaLabel="color-ring-loading"
                                wrapperStyle={{}}
                                wrapperClass="color-ring-wrapper"
                                colors={['#fff', '#fff', '#fff', '#fff', '#fff']}
                            /></center>) : "Submit"}
                        </button>

                    </form>
                </div>

            </div>
        </div>
    );
}

export default CreateCategory;
