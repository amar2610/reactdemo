import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

import ProductCard from './productCard'; // Make sure this path is correct
const Products = () => {
  const [pgs, setPgs] = useState([]);
  const data = useSelector((state) => state.Products.value);
  useEffect(() => {
   setPgs(data) 
  }, [data]);
  

  return (
    <div className="container mt-4">
        
      <div className="row">
        {pgs.map((pg) => (
          <ProductCard  pg={pg} />
        ))}
      </div>
    </div>
  );
};

export default Products;
