import React, { useState } from 'react';
import { useFormik } from 'formik';

import { useNavigate } from "react-router-dom";
import { UserAuth } from "../context/AuthContext";

import axios from 'axios';

import { ColorRing } from 'react-loader-spinner'
import * as Yup from 'yup';
function CreateProduct() {

    const [loading, setLoading] = useState(false);



    const { login } = UserAuth();
    const Navigate = useNavigate();

    const formik = useFormik({
        initialValues: {
            title: '',
            image: '',
            price: '',
            description: '',
            category: ''

        },

        validationSchema: Yup.object({

            title: Yup.string().required("Title is required"),
            price: Yup.string().required('Price Is Required'),
            description: Yup.string().required('Description Is Required'),
            category: Yup.string().required('Category ID Is Required'),
            image: Yup.string().required('image Is Required'),


        }),

        onSubmit: async () => {
            setLoading(true)
            setTimeout(async () => {
                try {
                    let images = [];

                    images.push(formik.values.image)
                    let produdetails = {
                        title: formik.values.title,
                        price: formik.values.price,
                        description: formik.values.description,
                        categoryId: formik.values.category,
                        images: images
                    }

                    const api = await axios.post("https://api.escuelajs.co/api/v1/products", produdetails);
                    console.log(api.data);


                    login({ username: 'Amar' });
                    Navigate('/desboard');
                }
                catch (error) {
                    console.log(error);

                    Navigate('/addproduct');
                }

                setLoading(false)
            }, 3000)
        }

    });

    return (
        <div >
            <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 bg-white dark:bg-gray-900 text-black dark:text-white">


                <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">
                    <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Add Product</h2>
                    <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Title</label>
                            <input
                                type="text"
                                name="title"
                                placeholder="Your title"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.title}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.title && formik.errors.title && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.title}</div>
                            )}
                        </div>
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">description</label>
                            <input
                                type="text"
                                name="description"
                                placeholder="Your discription"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.description}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.description && formik.errors.description && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.description}</div>
                            )}
                        </div>
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Images</label>
                            <input
                                type="text"
                                name="image"
                                placeholder="Your images"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.image}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.image && formik.errors.image && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.image}</div>
                            )}
                        </div>

                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Category</label>
                            <input
                                type="number"
                                name="category"
                                placeholder="Your category"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.category}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.category && formik.errors.category && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.category}</div>
                            )}
                        </div>
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">price</label>
                            <input
                                type="number"
                                name="price"
                                id="price"
                                placeholder="Your price"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.Price}
                                onChange={(e) => { formik.handleChange(e) }}
                                onBlur={formik.handleBlur}
                            />

                            {formik.touched.price && formik.errors.price && (
                                <div className="text-rose-700">{formik.errors.price}</div>
                            )}
                        </div>
                        <div>
                        </div>
                        <button
                            type="submit"
                            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800 disabled:bg-blue-200 disabled:cursor-not-allowed"
                            disabled={!formik.dirty || !formik.isValid}
                        >
                            {loading ? (<center> <ColorRing
                                visible={true}
                                height="40"
                                width="90"
                                ariaLabel="color-ring-loading"
                                wrapperStyle={{}}
                                wrapperClass="color-ring-wrapper"
                                colors={['#fff', '#fff', '#fff', '#fff', '#fff']}
                            /></center>) : "Submit"}
                        </button>

                    </form>
                </div>

            </div>
        </div>
    );
}

export default CreateProduct;
