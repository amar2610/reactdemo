import React, { useState, useEffect, useRef } from 'react';
import { useFormik } from 'formik';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { UserAuth } from "../context/AuthContext";
import axios from 'axios';
import { ColorRing } from 'react-loader-spinner';
import * as Yup from 'yup';

function UpdateProduct() {
    const { proId } = useParams();
    const datas = useSelector((state) => state.Products.value);
    const data = datas.filter(Product => Product.id == proId);

    const [loading, setLoading] = useState(false);
    const { login } = UserAuth();
    const navigate = useNavigate();
    const initialized = useRef(false); // Prevent re-initialization

    const formik = useFormik({
        initialValues: {
            title: '',
            image: '',
            price: '',
            description: ''
        },
        validationSchema: Yup.object({
            title: Yup.string().required("Title is required"),
            price: Yup.string().required('Price is required'),
            description: Yup.string().required('Description is required'),
            image: Yup.string().required('Image is required'),
        }),
        onSubmit: async () => {
            setLoading(true);
            setTimeout(async () => {
                try {
                    const images = [formik.values.image];
                    const productDetails = {
                        title: formik.values.title,
                        price: formik.values.price,
                        description: formik.values.description,
                        images: images
                    };

                    console.log("Updating product:", productDetails);

                    // ✅ Using PUT to update the product
                    const api = await axios.put(`https://api.escuelajs.co/api/v1/products/${proId}`, productDetails);
                    console.log(api.data);

                    login({ username: 'Amar' });
                    navigate('/desboard');
                } catch (error) {
                    console.error(error);
                    navigate(`/updateproduct/${proId}`);
                }
                setLoading(false);
            }, 3000);
        }
    });

    useEffect(() => {
        if (!initialized.current && data.length > 0) {
            formik.setValues({
                title: data[0].title || '',
                image: data[0].image || '',
                price: data[0].price || '',
                description: data[0].description || ''
            });
            initialized.current = true;
        }
    }, [data]);

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 dark:bg-gray-900 text-black dark:text-white">
            <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 dark:bg-gray-900">
                <h2 className="text-2xl font-bold mb-6 text-center">Update Product</h2>
                <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>
                    <div>
                        <label className="block">Title</label>
                        <input
                            type="text"
                            name="title"
                            placeholder="Product title"
                            className="input-style"
                            value={formik.values.title}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {formik.touched.title && formik.errors.title && (
                            <div className="text-rose-700">{formik.errors.title}</div>
                        )}
                    </div>
                    <div>
                        <label className="block">Description</label>
                        <input
                            type="text"
                            name="description"
                            placeholder="Product description"
                            className="input-style"
                            value={formik.values.description}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {formik.touched.description && formik.errors.description && (
                            <div className="text-rose-700">{formik.errors.description}</div>
                        )}
                    </div>
                    <div>
                        <label className="block">Image URL</label>
                        <input
                            type="text"
                            name="image"
                            placeholder="Image URL"
                            className="input-style"
                            value={formik.values.image}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {formik.touched.image && formik.errors.image && (
                            <div className="text-rose-700">{formik.errors.image}</div>
                        )}
                    </div>
                    <div>
                        <label className="block">Price</label>
                        <input
                            type="number"
                            name="price"
                            placeholder="Product price"
                            className="input-style"
                            value={formik.values.price}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {formik.touched.price && formik.errors.price && (
                            <div className="text-rose-700">{formik.errors.price}</div>
                        )}
                    </div>
                    <button
                        type="submit"
                        className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800 disabled:bg-blue-200 disabled:cursor-not-allowed"
                        disabled={!formik.dirty || !formik.isValid}
                    >
                        {loading ? (
                            <center>
                                <ColorRing
                                    visible={true}
                                    height="40"
                                    width="90"
                                    ariaLabel="color-ring-loading"
                                    wrapperClass="color-ring-wrapper"
                                    colors={['#fff', '#fff', '#fff', '#fff', '#fff']}
                                />
                            </center>
                        ) : "Submit"}
                    </button>
                </form>
            </div>
        </div>
    );
}

export default UpdateProduct;
