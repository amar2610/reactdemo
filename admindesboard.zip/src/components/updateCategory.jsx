import React, { useState, useEffect, useRef } from 'react';
import { useFormik } from 'formik';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { UserAuth } from "../context/AuthContext";
import axios from 'axios';
import { ColorRing } from 'react-loader-spinner';
import * as Yup from 'yup';

function UpdateCategory() {
    const { proId } = useParams();
    const datas = useSelector((state) => state.Category.value);
    const data = datas.filter(Product => Product.id == proId);

    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const initialized = useRef(false); 

    const formik = useFormik({
        initialValues: {
            name: '',
            image: '',
            
        },
        validationSchema: Yup.object({
            name: Yup.string().required("name is required"),
            image: Yup.string().required('Image is required'),
        }),
        onSubmit: async () => {
            setLoading(true);
            setTimeout(async () => {
                try {
                    const productDetails = {
                        name: formik.values.name,
                        image: formik.values.image
                    };
                    console.log(productDetails);
                    

                    const api = await axios.put(`https://api.escuelajs.co/api/v1/categories/${proId}`, productDetails);
                    console.log(api.data);

                    navigate('/category');
                } catch (error) {
                    console.error(error);
                    navigate(`/updatecategory/${proId}`);
                }
                setLoading(false);
            }, 3000);
        }
    });

    useEffect(() => {
        if (!initialized.current && data.length > 0) {
            formik.setValues({
                name: data[0].name || '',
                image: data[0].image || '',
            });
            initialized.current = true;
        }
    }, [data]);

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 dark:bg-gray-900 text-black dark:text-white">
            <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 dark:bg-gray-900">
                <h2 className="text-2xl font-bold mb-6 text-center">Update Name</h2>
                <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>
                    <div>
                        <label className="block">Name</label>
                        <input
                            type="text"
                            name="name"
                            placeholder="Product name"
                            className="input-style"
                            value={formik.values.name}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {formik.touched.name && formik.errors.name && (
                            <div className="text-rose-700">{formik.errors.name}</div>
                        )}
                    </div>
                   
                    <div>
                        <label className="block">Image URL</label>
                        <input
                            type="text"
                            name="image"
                            placeholder="Image URL"
                            className="input-style"
                            value={formik.values.image}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {formik.touched.image && formik.errors.image && (
                            <div className="text-rose-700">{formik.errors.image}</div>
                        )}
                    </div>
                   
                    <button
                        type="submit"
                        className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800 disabled:bg-blue-200 disabled:cursor-not-allowed"
                        disabled={!formik.dirty || !formik.isValid}
                    >
                        {loading ? (
                            <center>
                                <ColorRing
                                    visible={true}
                                    height="40"
                                    width="90"
                                    ariaLabel="color-ring-loading"
                                    wrapperClass="color-ring-wrapper"
                                    colors={['#fff', '#fff', '#fff', '#fff', '#fff']}
                                />
                            </center>
                        ) : "Submit"}
                    </button>
                </form>
            </div>
        </div>
    );
}

export default UpdateCategory;
