import React from 'react';
import { useDispatch } from 'react-redux';
import { delet } from '../app/slice/userslice';
const UserCard = (props) => {
    const dispatch = useDispatch();
    
        const Delete = () => {        
              dispatch(delet({ id: props.pg.id}));
              console.log(props.pg.id); 
          };

    return (
        <div className="col-md-4 mb-4">
            <div className="card h-100 shadow-sm">
                <img src={props.pg.avatar} className="card-img-top" alt={props.pg.name} style={{ height: '250px', objectFit: 'cover' }} />
                <div className="card-body">
                    <h5 className="card-title">{props.pg.name}</h5>
                    <p className="text-muted"><strong>Email:</strong> {props.pg.email}</p>
                    <button  type='button' className="btn btn-primary mt-2" onClick={Delete}>delete</button>
                    </div>
            </div>
        </div>
    );
};

export default UserCard;
