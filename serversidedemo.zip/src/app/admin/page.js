'use client'
import { revalidateProductsPage } from './action';

export default function Admin(){

    const revalidata= async()=>{
        
       await revalidateProductsPage();
    }
    return(
        <button
    onClick={()=>{
        revalidata();
    }}
    className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg m-1 hover:bg-blue-700 transition"
  >
    Revalidate Products
  </button>
    )
}