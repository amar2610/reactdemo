'use client';

import { useState } from 'react';

export default function StockTracker({ initialStock }) {
    const stockCount = Math.floor(Math.random() * 100) + 1;

  const [stock, setStock] = useState(stockCount);

  return (
    <div className="mt-4 p-4 border rounded-lg text-gray-900">
  <h2 className="text-lg font-semibold">Stock Tracker</h2>
  <p>Items in stock: <strong>{stock}</strong></p>
</div>
  );
}
