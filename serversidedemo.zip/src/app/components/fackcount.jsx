
export default function FackCount() {
    const totalCount = Math.floor(Math.random() * 100) + 1;
    const priceCount = Math.floor(Math.random() * 100) + 1;



  return (
    <div className="mt-4 p-4 border rounded-lg text-white">
  <h2 className="text-lg font-semibold">Calcualtion</h2>
  <p> Total Count: <strong>{totalCount}</strong></p>
  <p>Avrage Price: <strong>{priceCount}</strong></p>

</div>
  );
}