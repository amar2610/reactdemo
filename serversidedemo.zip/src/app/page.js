import Image from "next/image";
import Products from "./components/product";
import { Suspense } from "react";
export default function Home() {
  return (
   <Suspense fallback={<p>Loading.....</p>}> <Products/></Suspense>
  );
}
