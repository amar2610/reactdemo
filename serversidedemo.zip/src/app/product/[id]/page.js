'use client';
import StockTracker from "@/app/components/stocktraker";
import { useEffect, useState } from "react";
import useSWR from 'swr'

const fetcher = url => fetch(url).then(res => res.json());
 function ProductDetails ({ params }) {
  const { data: product, error, isLoading } = useSWR(
    `https://fakestoreapi.com/products/${params.id}`,
    fetcher
  );
 
  let[price,setPrice]=useState(100);
  let updateprice= Math.floor(Math.random() * 100) + 1;
 
    setInterval(()=>{
     setPrice(updateprice)
    },3000)
  
  
  

  
 


  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Failed to load product.</p>;

  return (
   

    <div>
          <main className="p-4">
  <h1 className="text-2xl font-bold mb-4">Product List</h1>

 

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">

   
      <div
        key={product.id}
        className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 p-4 relative flex flex-col"
      >
        <img
          src={product.image}
          alt={product.title}
          className="h-60 object-contain rounded-md mb-4"
        />

        <div className="flex-grow flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {product.title}
            </h3>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {price}
            </h3>
          </div>
          
          <div>
      {
          <StockTracker /> }         </div>

        </div>
      </div>
 
  </div>
</main>
</div>
    )
}
export default ProductDetails