import Link from "next/link";
import FackCount from "@/app/components/fackcount";
const  CategoriesProduct= async({params})=>{
    const catproduct = params.categoryname; 
    console.log("data", catproduct);
    const ProductData=await fetch(`https://fakestoreapi.com/products/category/${catproduct}`,{
        next:{revalidate:50}
    });
    const categoryData=await fetch('https://fakestoreapi.com/products/categories',{
        next:{revalidate:50}
    });
let category=await categoryData.json();
    
    let data=await ProductData.json();
    await new Promise(resolve=> setTimeout(resolve,3000));



    console.log(category);
    
    return(
    <div>
      {<FackCount/>}
          <main className="p-4">
  <h1 className="text-2xl font-bold mb-4">Product List</h1>
  <Link
    href={'/'}
    className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg m-1 hover:bg-blue-700 transition"
  >
    all
  </Link>
  {category.map((cat, index) => (
  <Link
    key={index}
    href={`/category/${cat}`}
    className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg m-1 hover:bg-blue-700 transition"
  >
    {cat}
  </Link>
))}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">

    {data.map((product) => (
      <div
        key={product.id}
        className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 p-4 relative flex flex-col"
      >
        <img
          src={product.image}
          alt={product.title}
          className="h-60 object-contain rounded-md mb-4"
        />

        <div className="flex-grow flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {product.title}
            </h3>
          </div>
          <div>

          <Link href={`product/${product.id}` }  className="text-blue-600 visited:text-purple-600 ...">Details</Link>
          </div>

        </div>
      </div>
    ))}
  </div>
</main>
</div>
    )
}
export default CategoriesProduct