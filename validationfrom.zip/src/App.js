import logo from './logo.svg';
import './App.css';
import SignupForm from './components/forms/formcomponent';

function App() {
  return (
    <SignupForm/>
  );
}

export default App;
