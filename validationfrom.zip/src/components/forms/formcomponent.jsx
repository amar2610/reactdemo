import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import SecondForm from './secondform';
function SignupForm() {
  const [hide, setHide] = useState(false);
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState(0);
  const myFunction = () => {
    let x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      age: '',
      password: '',
      confirm_password: '',
      terms: false,
    },
    validationSchema: Yup.object({
      name: Yup.string().trim().required("Name is required"),
      email: Yup.string().trim().email("Enter a valid email").required("Email is required"),
      age: Yup.string()
        .matches(/^\d{2}$/, "Enter valid age (2 digits)")
        .required("Age is required"),
      password: Yup.string().min(8).required("Password is required"),
      confirm_password: Yup.string()
        .oneOf([Yup.ref("password"), null], "Password and confirm-password shoud be same")
        .required("Confirm password is required"),
      terms: Yup.bool()
        .oneOf([true], "You must accept the terms and conditions")
        .required("Required")
    }),

    onSubmit: async () => {
      setLoading(true);
      try {
        const x = Math.floor(Math.random() * 10 + 1);
        setUserId(x);
        setTimeout(() => {
          setHide(true);
        }, 5000);

      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    },
  });

  return (

    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
      {!hide ?

        <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Create an Account</h2>
          <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>


            <div>
              <label className="block text-gray-700">Name</label>
              <input
                type="text"
                name="name"
                placeholder="Your full name"
                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formik.values.name}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.name && formik.errors.name && (
                <div className="text-rose-700">{formik.errors.name}</div>
              )}
            </div>


            <div>
              <label className="block text-gray-700">Email</label>
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.email && formik.errors.email && (
                <div className="text-rose-700">{formik.errors.email}</div>
              )}
            </div>


            <div>
              <label className="block text-gray-700">Age</label>
              <input
                type="text"
                name="age"
                placeholder="Your age"
                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formik.values.age}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.age && formik.errors.age && (
                <div className="text-rose-700">{formik.errors.age}</div>
              )}
            </div>


            <div>
              <label className="block text-gray-700">Password</label>
              <input
                type="password"
                name="password"
                id="password"
                placeholder="Your password"
                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              /><span onClick={myFunction}>show</span>
              {formik.touched.password && formik.errors.password && (
                <div className="text-rose-700">{formik.errors.password}</div>
              )}
            </div>

            <div>
              <label className="block text-gray-700">Confirm Password</label>
              <input
                type="password"
                name="confirm_password"
                placeholder="Confirm password"
                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formik.values.confirm_password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.confirm_password && formik.errors.confirm_password && (
                <div className="text-rose-700">{formik.errors.confirm_password}</div>
              )}
            </div>


            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  name="terms"
                  checked={formik.values.terms}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  className="border-gray-300 focus:outline-none focus:ring-blue-500"
                />
                <span>I agree to the Terms & Conditions</span>
              </label>
              {formik.touched.terms && formik.errors.terms && (
                <div className="text-rose-700">{formik.errors.terms}</div>
              )}
            </div>


            <button
              type="submit"
              className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800"
            >
              {loading ? "Submitting" : "Submite"}
            </button>

          </form>
        </div>
        : <SecondForm userId={userId} />}
    </div>
  );
}

export default SignupForm;
