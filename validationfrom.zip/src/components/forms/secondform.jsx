import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

function SecondForm(props) {
    const [loading,setLoading]=useState(false);
  const formik = useFormik({
    initialValues: {
      title: '',
      body: '',
    
    },
    validationSchema: Yup.object({
      title: Yup.string().trim().required("title is required"),
      body: Yup.string().trim().required("body  is required"),
     
    }),
    onSubmit: async (values) => {
        setLoading(true);
        try {
            console.log(props.userId);
            
          const x = props.userId
          const data = { ...values, user_id: x };
          const res = await axios.post('https://jsonplaceholder.typicode.com/posts', data);
          console.log('Response:', res.data);
        } catch (err) {

          console.error(err);
        } finally {
          setLoading(false);
        }
      },
  });

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8">
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Create an Account</h2>
        <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>

     
          <div>
            <label className="block text-gray-700">Title</label>
            <input
              type="text"
              name="title"
              placeholder="Your full name"
              className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.title}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.title && formik.errors.title && (
              <div className="text-rose-700">{formik.errors.title}</div>
            )}
          </div>

          <div>
            <label className="block text-gray-700">Body</label>
            <input
              type="text"
              name="body"
              placeholder="Your body data"
              className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.body}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.body && formik.errors.body && (
              <div className="text-rose-700">{formik.errors.body}</div>
            )}
          </div>

        

      
          <button
            type="submit"
            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800"
          >
            {loading?"Submitting":"Submite"}
          </button>

        </form>
      </div>
    </div>
  );
}

export default SecondForm;
