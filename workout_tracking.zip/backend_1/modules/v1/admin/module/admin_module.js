const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
class userModule {
    
    async UserListing(requireData) {
        try {
            
                let [result] = await database.query("select * from tbl_user where role='user'");
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "user is not found",
                        data: []
                    }
                }
             
          
            return {
                code: error_code.success,
                keyword: "success",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "user is not found",
                data: []
            }
        }
    }
    async WorkoutListing(requireData) {
        try {
            
                let [result] = await database.query("select * from tbl_exercise_name ");
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "exercise is not found",
                        data: []
                    }
                }
             
          
            return {
                code: error_code.success,
                keyword: "success",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "exercise is not found",
                data: []
            }
        }
    }
    async DeleteUserWorkOut(requireData) {
        try {
                let insert = "UPDATE tbl_user_exercise SET  is_deleted=1 WHERE id = ?";
                let [result] = await database.query( insert,requireData.id);
                console.log(result);
                
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "userexercise is not deleted",
                        data: []
                    }
                }
             
          
            return {
                code: error_code.success,
                keyword: "userexercise is deleted",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "userexercise is not deleted",
                data: []
            }
        }
    }
    async DeleteDefaultWorkOut(requireData) {
        try {
                let insert = "UPDATE tbl_exercise_name SET  is_delete=1 WHERE id = ?";
                let [result] = await database.query( insert,requireData.id);
                console.log(result);
                
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "default exercise is not deleted",
                        data: []
                    }
                }
             
          
            return {
                code: error_code.success,
                keyword: "default exercise is deleted",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "userexercise is not deleted",
                data: []
            }
        }
    }
    async GetUserWorkout(requireData) {
        try {
                let insert = "select e.*,.name as username from tbl_user_exercise as e  inner join tbl_user as u on u.id=e.user_id ";
                let [result] = await database.query(insert);
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "workout  is not found",
                        data: []
                    }
                }
             
          
            return {
                code: error_code.success,
                keyword: "success",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "workout  is not found",
                data: []
            }
        }
    }
     async addExercise(requireData) {
            try {
                let data = {
                    name: requireData.name,
                }
                let [item] = await database.query("select * from tbl_exercise_name where  name like ? ", [data.name]);
                if (item.length <= 0) {
                    let [result] = await database.query("insert into  tbl_exercise_name set?", [data]);
                    if (result.length <= 0) {
                        return {
                            code: error_code.invalid_input,
                            keyword: " exercise  is not added",
                            data: []
                        }
                    }
                    return {
                        code: error_code.success,
                        keyword: "exercise  is added",
                        data: result
                    }
                } else {
                 
                        return {
                            code: error_code.invalid_input,
                            keyword: "Exercise  alredy added",
                            data: []
                        }
                    }
            } catch (Error) {
                console.log(Error);
                return {
                    code: error_code.invalid_input,
                    keyword: "exercise  is not added",
                    data: []
                }
            }
    
        }
}
module.exports = new userModule();