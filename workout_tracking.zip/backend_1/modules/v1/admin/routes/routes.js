let admin=require("../controller/admin");
let CustomeRoute=(app)=>{
    app.post("/v1/admin/userlisting",admin.userListing);
    app.post("/v1/admin/deleteworkout",admin.DeleteUserWorkout);
    app.post("/v1/admin/deletedefaultworkout",admin.DeletedefaultWorkout);

    app.post("/v1/admin/addworkout",admin.AddWorkOut);
    app.post("/v1/admin/workoutlisting",admin.WorkoutListing);
    app.post("/v1/admin/userworkoutlisting",admin.userWorkoutListing);

  






}
module.exports=CustomeRoute;