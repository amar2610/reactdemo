let admin_module = require("../module/admin_module");
const middleware = require("../../../../middelware/validation");
let validation_rules = require("../../../../middelware/validation_rules");
const common = require("../../../../utilities/common");
const { required } = require("../../../../language/en");
class admin {

    async userListing(req, res) {

        let data = "";

        // if (Object.keys(data).length != 0) {
        //     data = JSON.parse(common.decryptPlain(req.body));
        //     console.log(data);  
        // }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.UserListing(data);
            middleware.send_response(req, res, respons);
        }
    }
    async WorkoutListing(req, res) {

        let data = "";

        // if (Object.keys(data).length != 0) {
        //     data = JSON.parse(common.decryptPlain(req.body));
        //     console.log(data);  
        // }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.WorkoutListing(data);
            middleware.send_response(req, res, respons);
        }
    }
    async userWorkoutListing(req, res) {

        let data = "";

        // if (Object.keys(data).length != 0) {
        //     data = JSON.parse(common.decryptPlain(req.body));
        //     console.log(data);  
        // }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.GetUserWorkout(data);
            middleware.send_response(req, res, respons);
        }
    }
    async DeleteUserWorkout(req, res) {

        let data = req.body;


        if (data != undefined) {

            data = JSON.parse(common.decryptPlain(req.body));


        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.DeleteUserWorkOut(data);
            middleware.send_response(req, res, respons);
        }
    }
    async DeleteUser(req, res) {

        let data = req.body;


        if (data != undefined) {

            data = JSON.parse(common.decryptPlain(req.body));


        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.DeleteUser(data);
            middleware.send_response(req, res, respons);
        }
    }
    async AddWorkOut(req, res) {

        let data = req.body;


        if (data != undefined) {

            data = JSON.parse(common.decryptPlain(req.body));


        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.addExercise(data);
            middleware.send_response(req, res, respons);
        }
    }
    async DeletedefaultWorkout(req, res) {

        let data = req.body;


        if (data != undefined) {

            data = JSON.parse(common.decryptPlain(req.body));


        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons = await admin_module.DeleteDefaultWorkOut(data);
            middleware.send_response(req, res, respons);
        }
    }

  
   
}

module.exports = new admin();