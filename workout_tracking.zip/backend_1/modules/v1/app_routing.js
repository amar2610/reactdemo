class routing{
    v1(app){
        let user=require("../v1/user/routes/routes");
        let admin=require("../v1/admin/routes/routes");
        admin(app);
        user(app);
    }
}
module.exports=new routing();