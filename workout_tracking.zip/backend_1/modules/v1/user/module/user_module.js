const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
const jwt = require("jsonwebtoken");

require('dotenv').config()
class userModule {
    async signUp(requireData) {
        try {
                let data = {
                    name: requireData.name,
                    email: requireData.email,
                    gender:requireData.gender,
                    weight:requireData.weight,
                    height:requireData.height,
                    password:await common.getHashedPassword(requireData.password)
                }
                
                let [check] = await database.query("select * from tbl_user where email=? and is_deleted='0'", [data.email]);
                if (check.length > 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "email  is alredy used",
                        data: []
                    }
                }
                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    }
                }
               
                let token=jwt.sign(
                    { id: result.insertId }, // Payload
                    process.env.SECRET,              // Secret
                    { expiresIn: "1d" }                 // Expiry
                  );
                  console.log("token",token);
            result.token=  token
            return {
                code: error_code.success,
                keyword: "user is register",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "user is not register",
                data: []
            }
        }
    }
    async logIn(requireData) {
            let data = {
                password: requireData.password
            }
            let password="";
            let [storedpassword]= await database.query("select * from tbl_user where email=?",[requireData.email]);
            if(storedpassword.length>0){
                
                password=storedpassword[0].password
            }else{
                return {
                    code: error_code.no_data_found,
                    keyword: "email not found",
                    data: []
                }
            }       
            console.log(data.password);
            
            let check =  await common.comparePasswords(data.password,password);
            if (check == true) {
                // common.SetToken( storedpassword[0].id);
                let token=jwt.sign(
                    { id: storedpassword[0].id },  // Payload
                    process.env.SECRET,              // Secret
                    { expiresIn: "1d" }                 // Expiry
                  );
                  console.log("token",token);
            storedpassword[0].token=  token
                return {
                    code: error_code.success,
                     keyword: "login_success",
                    data:storedpassword
                }
            }
        
        return {
            code: error_code.no_data_found,
            keyword: "user not found"
        }


    }
    async ExerciseListing(requireData) {
        try {
                    console.log(" user id is ",requireData.user_id);
                let [result] = await database.query("SELECT e.name FROM tbl_exercise_name as e where e.is_delete=0 UNION SELECT u.name FROM tbl_user_custom_exercise as u WHERE u.user_id=? and u.day like(SELECT dayName(now()));",[requireData.user_id]);
                if (result.length >0) {
                    return {
                        code: error_code.success,
                        keyword: "success",
                        data: result
                        
                    }
                }
            return {
                code: error_code.not_register,
                keyword: "Exircise is not found",
                data: []
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "Exircise is not found",
                data: []
            }
        }
    }
    async scheduleExerciseListing(requireData) {
        try {
                    console.log(" user id is ",requireData.user_id);
                let [result] = await database.query("SELECT * FROM tbl_user_schedule_exercise where user_id=?",[requireData.user_id]);
                if (result.length >0) {
                    return {
                        code: error_code.success,
                        keyword: "success",
                        data: result
                        
                    }
                }
            return {
                code: error_code.not_register,
                keyword: "Exircise is not found",
                data: []
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "Exircise is not found",
                data: []
            }
        }
    }
    async addExercise(requireData) {
        try {
            let data = {
                user_id:requireData.user_id,
                name: requireData.name,
                day: requireData.day,
            }
            let [item] = await database.query("select * from tbl_user_custom_exercise where user_id=? and name like ? and day like ?", [requireData.user_id,data.name,data.day]);
            if (item.length <= 0) {
                let [result] = await database.query("insert into  tbl_user_custom_exercise set?", [data]);
                if (result.length <= 0) {
                    return {
                        code: error_code.invalid_input,
                        keyword: " exercise  is not added",
                        data: []
                    }
                }
                return {
                    code: error_code.success,
                    keyword: "exercise  is added",
                    data: result
                }
            } else {
             
                    return {
                        code: error_code.invalid_input,
                        keyword: "Exercise  alredy added",
                        data: []
                    }
                }
        } catch (Error) {
            console.log(Error);
            return {
                code: error_code.invalid_input,
                keyword: "exercise  is not added",
                data: []
            }
        }

    }
  
    async addExerciseDetails(requireData) {
        try {
                let data = {
                    user_id:requireData.user_id,
                    exercise_name:requireData.exercise_name,
                    sets:requireData.sets,
                    reps:requireData.reps,
                    weight:requireData.weight,
                }       
                if(requireData.data){
                    data.date=requireData.data

                }     
                let insert = "insert into tbl_user_exercise set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "exercise details is  not  register",
                        data: []
                    }
                }
               
            
            return {
                code: error_code.success,
                keyword: "exercise details is register",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "exercise details is not register",
                data: []
            }
        }
    }

    async secheduleExercise(requireData) {
        try {
                let data = {
                    user_id:requireData.user_id,
                    name:requireData.name,
                }       
                if(requireData.date){
                    data.date=requireData.date

                }     
                let insert = "insert into tbl_user_schedule_exercise set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return {
                        code: error_code.not_register,
                        keyword: "exercise is  not  register",
                        data: []
                    }
                }
               
            
            return {
                code: error_code.success,
                keyword: "exercise  is register",
                data: result
            }
        } catch (Error) {
            console.log(Error);

            return {
                code: error_code.not_register,
                keyword: "exercise  is not register",
                data: []
            }
        }
    }
  async GetWorkoutHistory(requireData) {
            try {
                    let insert = "select * from tbl_user_exercise  WHERE user_id = ? and is_active=1";
                    let [result] = await database.query(insert,[requireData.user_id]);
                    if (result.length < 0) {
                        return {
                            code: error_code.not_register,
                            keyword: "workout  is not found",
                            data: []
                        }
                    }
                 
              
                return {
                    code: error_code.success,
                    keyword: "success",
                    data: result
                }
            } catch (Error) {
                console.log(Error);
    
                return {
                    code: error_code.not_register,
                    keyword: "workout  is not found",
                    data: []
                }
            }
        }

  async GetWorkoutdeilydata(requireData) {
            try {
                    let insert = "SELECT w.date, SUM(w.reps * w.sets) AS volume FROM tbl_user_exercise as w WHERE w.user_id = ? GROUP BY date(w.date)";
                    let [result] = await database.query(insert,[requireData.user_id]);
                    if (result.length < 0) {
                        return {
                            code: error_code.not_register,
                            keyword: "workout data  is not found",
                            data: []
                        }
                    }
                 
              
                return {
                    code: error_code.success,
                    keyword: "success",
                    data: result
                }
            } catch (Error) {
                console.log(Error);
    
                return {
                    code: error_code.not_register,
                    keyword: "workout data is not found",
                    data: []
                }
            }
        }


}
module.exports = new userModule();