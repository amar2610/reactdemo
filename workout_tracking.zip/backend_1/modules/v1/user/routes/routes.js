let user=require("../controller/user");
let CustomeRoute=(app)=>{
    app.post("/v1/user/signup",user.Signup);
    app.post("/v1/user/login",user.Login);
    app.post("/v1/user/exerciselisting",user.ExerciseListing);
    app.post("/v1/user/addexercise",user.addExercise);
    app.post("/v1/user/addexercisedetails",user.addEserciseDetails);
    app.post("/v1/user/getworkouthistory",user.GetWorkOutHistory);  
    app.post("/v1/user/deailyworkout",user.GetDeailyWorkoutdata);  
    app.post("/v1/user/scheduleworkout",user.scheduledeExercise);  
    app.post("/v1/user/scheduleworkoutlisting",user.SchuedulExerciseListing);  



  
   

 






  



  










 








    













}
module.exports=CustomeRoute;