let userModule = require("../module/user_module");
const middleware = require("../../../../middelware/validation");
let validation_rules = require("../../../../middelware/validation_rules");
const common = require("../../../../utilities/common");
class user {
    async Signup(req,res) {

        let data = req.body;
        console.log(data);
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
        }
        console.log("data",data);
        
        let rules=validation_rules.signUp;
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.signUp(data);
             middleware.send_response(req, res,respons);
        }
    }

    async Login(req,res) {

        let data = req.body;
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
        }
        
        let rules=validation_rules.blog;
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.logIn(data);
             middleware.send_response(req, res,respons);
        }
    }
    
  
     async ExerciseListing(req,res) {
    
            let data = {};
    
            // if (Object.keys(data).length != 0) {
            //     data = JSON.parse(common.decryptPlain(req.body));
            //     console.log(data);  
            // }
            let rules="";
            data.user_id=req.user_id
            let message = {
                required: req.language.required,
            }
            let key = {}
            if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
                let respons= await userModule.ExerciseListing(data);
                 middleware.send_response(req, res,respons);
            }
        }
        async SchuedulExerciseListing(req,res) {
    
            let data = {};
    
            // if (Object.keys(data).length != 0) {
            //     data = JSON.parse(common.decryptPlain(req.body));
            //     console.log(data);  
            // }
            let rules="";
            data.user_id=req.user_id
            let message = {
                required: req.language.required,
            }
            let key = {}
            if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
                let respons= await userModule.scheduleExerciseListing(data);
                 middleware.send_response(req, res,respons);
            }
        }
    async UpdateBlog(req,res) {

        let data = req.body;
        console.log(data);
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
            
            
        }
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.UpdateBlog(data);
             middleware.send_response(req, res,respons);
        }
    }
    async addExercise(req,res) {

        let data = req.body;
        console.log(data);
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
            
            
        }
        data.user_id=req.user_id;
        console.log(req.user_id);
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.addExercise(data);
             middleware.send_response(req, res,respons);
        }
    }

    async scheduledeExercise(req,res) {

        let data = req.body;
        console.log(data);
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
            
            
        }
        data.user_id=req.user_id;
        console.log(req.user_id);
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.secheduleExercise(data);
             middleware.send_response(req, res,respons);
        }
    }
    async placeOrder(req,res) {

        let data = req.body;
        console.log(data);
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
            
            
        }
        data.user_id=req.user_id;
        console.log(req.user_id);
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.placeOrder(data);
             middleware.send_response(req, res,respons);
        }
    }
    async addEserciseDetails(req,res) {

        let data = req.body;
        console.log(data);
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
            
            
        }
        data.user_id=req.user_id;
        console.log(req.user_id);
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.addExerciseDetails(data);
             middleware.send_response(req, res,respons);
        }
    }
   
    async addPayment(req,res) {

        let data = req.body;
        console.log(data);
        
        
        if ( data!= undefined) {
            
            data = JSON.parse(common.decryptPlain(req.body));
            
            
        }
        data.user_id=req.user_id;
        console.log(req.user_id);
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.addPayment(data);
             middleware.send_response(req, res,respons);
        }
    }
    async CartItems(req,res) {

        let data = {};
        
        data.user_id=req.user_id;
        console.log(req);
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.CartItemListing(data);
             middleware.send_response(req, res,respons);
        }
    }
  
    async UpdateProfile(req,res) {

        let data = {};
        
        data.user_id=req.user_id;
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.UpdateProfile(data);
             middleware.send_response(req, res,respons);
        }
    }
    
    async GetWorkOutHistory(req,res) {

        let data = {};
        
        data.user_id=req.user_id;
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.GetWorkoutHistory(data);
             middleware.send_response(req, res,respons);
        }
    }

    async GetDeailyWorkoutdata(req,res) {

        let data = {};
        
        data.user_id=req.user_id;
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.GetWorkoutdeilydata(data);
             middleware.send_response(req, res,respons);
        }
    }
    async GetOrders(req,res) {

        let data = {};
        
        data.user_id=req.user_id;
        
        let rules="";
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            let respons= await userModule.GetOrders(data);
             middleware.send_response(req, res,respons);
        }
    }
}

module.exports = new user();