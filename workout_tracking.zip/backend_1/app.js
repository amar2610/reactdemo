let express=require("express");
let app_rouring=require("./modules/v1/app_routing");
const  config  = require("./config/config");
const cors= require('cors');
require('dotenv').config();
const common = require("./utilities/common");
let app=express();
app.use(cors({
    origin: 'http://localhost:3000', // your frontend address
    methods: ['GET', 'POST','PUT'],         // allow these method
    credentials: true                // if you are using cookies, auth headers
  }));
app.use(express.text());
app.use('/',require('../backend/middelware/validation').extractHeaderLanguage);
app.use('/',require('../backend/middelware/validation').validatorApikey);
app.use('/',require('../backend/middelware/validation').validatorHeaderToken);
app_rouring.v1(app);
app.listen(config.server_listner,()=>{
    console.log("server running on ",config.server_listner);
    
})
