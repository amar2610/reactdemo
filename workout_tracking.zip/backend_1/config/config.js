
let env={
    
    server_listner:3035,

    api_key:"workout",
   
};
 module.exports=env;