let mysql=require("mysql2/promise");
let credential={};
require('dotenv').config()
credential={
    host:process.env.HOST,
    user:process.env.USER,
    password:process.env.PASSWORD,
    database:process.env.DATABASE,
    dateString:process.env.DATESTRING,
    port:process.env.PORT
}
try{
let database=mysql.createPool(credential);
if(database){
    console.log("database is connected");
    module.exports=database;
}
}catch(Error){
    console.log("data base is not connected ",Error);
    
}