var message = {
    "required": "ال :attr الحقل مطلوب",
    "email": "الرجاء إدخال صالحة :attr",
    "rest_keywords_required_message": "تفضل :attr",  
    "rest_keywords_unique_email_error":"Hey { username } ! هذا البريد الإلكتروني قيد الاستخدام بالفعل.",
    "rest_keywords_something_went_wrong":"هناك خطأ ما { username }",
    "rest_keywords_success":"نجاح",
    "not_verified": "Hmm your mobile number/email has not yet been verified",
    "login_invalid_credential": "Invalid credentials",
    "login_success": "Login Success!",
    "header_key_value_incorrect": "Unauthorized access of api, invalid value for api key",
    "header_authorization_token_error": "Unauthorized access of api, Invalid authorization token please check you request",
    "no_data_found": "No data found",
    "data_found": "Data found",
    
    "rest_keywords_password":'password'
}

module.exports = message;