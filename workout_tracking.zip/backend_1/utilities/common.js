const DataBase=require('../config/databse')
const crypto = require('crypto');
const bcrypt=require('bcrypt');
const SECRET_KEY = "xza548sa3vcr641b5ng5nhy9mlo64r6k";
const IV_STRING = "5ng5nhy9mlo64r6k";

const key = crypto.createHash('sha256').update(SECRET_KEY).digest();
const iv = Buffer.from(IV_STRING);


class common {
    Response(res, message) {
        res.json(message);
    }

    generatetocken(length) {
        let posible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        let text = "";
        for (let i = 0; i < length; i++) {
            text += posible.charAt(Math.floor(Math.random() * posible.length));
        }
        return text;
    }
    // Encrypt function
    encryptPlain(text) {
        const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return encrypted;
    }
    
    // Decrypt function
    decryptPlain(encryptedText) {
        const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
        let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }

    async getHashedPassword(password) {
        const saltRounds = 10
        try{
            const hashedPassword = await bcrypt.hash(password,saltRounds);
            return hashedPassword
        }catch(err){
            return {
                code :"401",
                keyword : "error in password bycrypt !",
                data : "Error in ByCrypt in Password !"
            }
        }
    }
SetToken(user_id) {
    let tokan = this.generatetocken(40);
    let updatetokan = "update tbl_device set token=? where user_id=?";

    DataBase.query(updatetokan, [tokan, user_id], (error, result) => {
        if (error) {
            console.log("operation faild", error);
        }
        if (result <= 0) {
            console.log("token in not generated");
        }
        console.log("token generated");

    })
}

async comparePasswords(plainPassword, hashedPassword) {
            try {
                const match = await bcrypt.compare(plainPassword, hashedPassword);
                if (match) {
                    console.log(" Password matched");
                    return true;
                } else {
                    console.log(" Password did not match");
                    return false;
                }
            } catch (error) {
                console.error("Error during password comparison:", error);
                return false;
            }
        }

   
}
module.exports = new common();