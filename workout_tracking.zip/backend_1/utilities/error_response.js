let error_code={
    operation_failed:"0",
    success:"1",
    social_id_not_register:"11",
    otp_not_veryfied:"4",
    no_data_found:"12",
    not_approve:"11",
    inactive_account:"3",
    code_null:"8",
    not_register:"12",
    data_already_exist:"2",
    invalid_input:"5"
}
module.exports=error_code;