const { signUp } = require("../modules/v1/user/module/user_module")

const checkValidationRules = {
    signUp:{
        name:'required',
        email:'required',
        password:'required',
        weight:'required',
        height:'required'
    },
    login: {
      login_type:'required|in:s,g,f,i',
      email:'required_if:login_type,s',
      password:'required_if:login_type,s',
      social_id:'required_unless:login_type,s',
      deviceType:"required|in:a,i",
    },
    productDetail:{
        product_id:"required"
    },
    product: {
        name:"required",
        category_id:"required",
        price: "required",
       
    },
    category: {
        name:"required",
        image_url:"required"
       
    },
  
   
    setlocation:{
        address_line:"required",
        city:"required",
        state:"required",
        pincode:"required",
        country:"required",
    },
    addtocart:{
        product_id:"required",
        qty:"required"
    }
}
module.exports = checkValidationRules
