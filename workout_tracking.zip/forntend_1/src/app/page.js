'use client';
import { useRouter } from "next/navigation"; 
import Cookies from 'js-cookie';
import { useState } from "react";
import { userLogin } from "../app/apis/page";
import Link from "next/link";
export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  let router=useRouter();
  const handlerSubmit = async () => {

  const logdata=  {"email":email,"password":password}
   let resultdata = await userLogin(logdata);
   if(resultdata){
   
    let token ="";
    let role="";
    if(resultdata.data[0].role=='user'){
      
      token=resultdata.data[0].token
      role=resultdata.data[0].role
      localStorage.setItem("token", resultdata.data[0].token)
      localStorage.setItem("role", resultdata.data[0].role)
      router.push('/user/userdesboard')
    } else if(resultdata.data[0].role=='admin'){
      token=resultdata.data[0].token
      role=resultdata.data[0].role
      localStorage.setItem("role", resultdata.data[0].role)
      localStorage.setItem("token", resultdata.data[0].token)
      router.push('/admin/desboard')
    }
    Cookies.set('token', token, { expires: 7 });
    Cookies.set('role', role, { expires: 7 });

   }else{
    setError('invalid email or password')
   }
   
   
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
  <div
    className="bg-white p-8 rounded-xl shadow-md w-full max-w-sm"
  >
    <h2 className="text-2xl font-semibold mb-6 text-center text-gray-800">
      Login Page
    </h2>

    <input
  type="text"
  placeholder="email"
  value={email}
  onChange={(e) => setEmail(e.target.value)}
  required
  className="w-full px-4 py-2 mb-4 border border-gray-300 rounded-lg 
             focus:outline-none focus:ring-2 focus:ring-blue-500 
             placeholder-gray-800 text-gray-900 caret-black"
/>

<input
  type="password"
  placeholder="Password"
  value={password}
  onChange={(e) => setPassword(e.target.value)}
  required
  className="w-full px-4 py-2 mb-4 border border-gray-300 rounded-lg 
             focus:outline-none focus:ring-2 focus:ring-blue-500 
             placeholder-gray-800 text-gray-900 caret-black"
/>

    <button
      type="submit"
      onClick={()=>handlerSubmit()}
      className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-300"
    >
      Login
    </button>
    <div className="text-center mt-4">
  <Link
    href={"/signup"}
    className="text-sm text-blue-600 hover:underline"
  >
    Don’t have an account? Sign up
  </Link>
</div>


    {error && (
      <p className="mt-4 text-center text-red-600 font-medium">{error}</p>
    )}
</div>
</div>

  );
}




