"use client"
import React, { useEffect, useState } from "react";
import { AdminWorkoutlisting , DeleteDefaultworkout } from "@/app/apis/page";
import Sidebar from "@/app/components/sidebar";

const UsersListing = () => {
    const [users, setUsers] = useState([]);
    const [active,Setactive]= useState('');
    
    const fetchUsers = async () => {
        try {
          const userdata = await AdminWorkoutlisting(); 
          setUsers(userdata.data);
        } catch (error) {
          console.error("Failed to fetch users:", error);
        }
      };
    useEffect(() => {
      fetchUsers();
    }, []);
   
    const DeleteWorkout=async(id)=>{
        
        const confirmed = window.confirm("Are you sure you want to delete  this workout ?");
        if (!confirmed) return;
      
        try {
            const deletedata={
                "id":id
            }
          const result = await DeleteDefaultworkout(deletedata); 
          if (result) {
            fetchUsers();
          }
        } catch (error) {
          console.error("Failed to delete user:", error);
        }
    }
  return (
    <div className="min-h-screen bg-gray-100 flex flex-row">
    <div className="w-64">
      <Sidebar />
    </div>
  
    <div className="flex-1 flex flex-col items-center justify-start px-4 py-8">
      <div className="max-w-6xl w-full bg-white rounded-2xl shadow-lg p-6 text-gray-900 text-base">
        <h2 className="text-3xl font-extrabold mb-6 text-center text-black">Workout Listing</h2>
  
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto border-collapse border border-gray-300">
            <thead className="bg-gray-300 text-black text-base font-semibold">
              <tr>
                <th className="border border-gray-400 px-4 py-3 text-left">#</th>
            

                <th className="border border-gray-400 px-4 py-3 text-left">Name</th>

              
                <th className="border border-gray-400 px-4 py-3 text-center">Status</th>
                <th className="border border-gray-400 px-4 py-3 text-center">Actions</th>

              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? (
                users.map((user, index) => (
                  <tr key={user.id} className="hover:bg-gray-100">
                    <td className="border border-gray-300 px-4 py-3 text-gray-900">{user.id}</td>
                  
                    <td className="border border-gray-300 px-4 py-3 text-gray-900">{user.name}</td>

                  
                    <td className="border border-gray-300 px-4 py-3">
                      <button onClick={()=>updateStatus(user)} className={`px-3 py-2 rounded-full text-sm font-bold ${user.is_delete == 0 ? 'bg-green-200 text-green-900' : 'bg-red-200 text-red-900'}`}>
                        {user.status}
                      </button>
                    </td>
                    <td className="border border-gray-300 px-4 py-3 text-center">
                      <button className="text-red-700 hover:underline font-semibold" onClick={()=>DeleteWorkout(user.id)}>Delete</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center py-4 text-gray-600 font-medium">No users found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
  
  );
};

export default UsersListing;
