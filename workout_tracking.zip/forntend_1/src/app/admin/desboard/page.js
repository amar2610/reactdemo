'use client'
import { useEffect, useState } from "react";
import Sidebar from "../../components/sidebar";
import { AdminWorkoutlisting } from "@/app/apis/page";
import { UserListing } from "@/app/apis/page";

export default function Home() {



  const[users,SetUser]=useState(0);
  const[workouts,SetWorkout]=useState(0);
  const fetchdata= async()=>{
    let user= await UserListing();
    let usercount=JSON.parse(user)
    console.log(usercount);
    
    let workout= await AdminWorkoutlisting();
    
    SetUser(usercount.data.length);
    SetWorkout(workout.data.length);
  }
  useEffect(()=>{
    fetchdata();
  },[])
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen bg-gray-100 text-gray-800">
        <main className="p-6">
          <h2 className="text-3xl font-bold mb-6">Dashboard</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white shadow p-6 rounded text-lg font-semibold">
              👥 Total Users: <span className="font-bold">{users}</span>
            </div>
            <div className="bg-white shadow p-6 rounded text-lg font-semibold">
              Total WorkOut: <span className="font-bold">{workouts}</span>
            </div>
           
          </div>
        </main>
      </div>
    </div>
  );
}
