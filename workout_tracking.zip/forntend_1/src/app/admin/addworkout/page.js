'use client'

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AddNewWorkout } from "@/app/apis/page";
import Sidebar from "@/app/components/sidebar";
export default function SetExercise() {
    const route = useRouter();
    const [exercise, SetExercise] = useState(0);

    const submitdata = async () => {
        let data = {
            "name": exercise,
        }
        let response = await AddNewWorkout(data)
        if (response) {
            route.push('/admin/desboard');
        }
    }

    return (

        <div className="min-h-screen bg-gray-100 flex flex-row">
            <div className="w-64">
                <Sidebar />
            </div>

            <div className="flex-1 flex flex-col mt-20 items-center justify-start px-4 py-8">
                <div className="max-w-6xl w-150   bg-white rounded-2xl shadow-lg p-6 text-gray-900 text-base">
                    <form>
                        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Add New WorkOut</h2>

                        <div>
                            <label className="block text-gray-700 ">Exercise Name</label>
                            <input
                                type="text"
                                name="name"
                                onChange={(e) => SetExercise(e.target.value)}
                                placeholder="Enter workout name"
                                className="mt-1 w-full px-4  mb-6 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                required
                            />

                        </div>
                        <button
                            type="button"
                            onClick={() => submitdata()}
                            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800"
                        >
                            Submit
                        </button>

                    </form>

                </div>
            </div>
        </div>
    )
}




