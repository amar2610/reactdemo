'use client'
import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { userSignup } from '@/app/apis/page';
function SignupForm() {
  const router=useRouter();
  const [loading, setLoading] = useState(false);
  const myFunction = () => {
    let x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      password: '',
      weight:'',
      height:'',
      gender:'',
      confirm_password: '',
    },
    validationSchema: Yup.object({
      name: Yup.string()
        .trim()
        .required("Name is required"),
        gender: Yup.string()
        .trim()
        .required("Gender is required"),
        height: Yup.string()
        .trim()
        .required("heigh is required"),
        weight: Yup.string()
        .trim()
        .required("width is required"),
      email: Yup.string()
        .trim()
        .email("Enter a valid email")
        .required("Email is required"),
    
      password: Yup.string()
        .min(8, "Password must be at least 8 characters")
        .required("Password is required"),
    
      confirm_password: Yup.string()
        .oneOf([Yup.ref("password"), null], "Password and confirm-password should be the same")
        .required("Confirm password is required"),
    }),    

    onSubmit: async () => {
      setLoading(true);
      try {
        let data = {
          name: formik.values.name,
          email: formik.values.email,
          height: formik.values.height,
          password: formik.values.password,
          gender:  formik.values.gender,
          weight: formik.values.weight,
        }

      let result= await userSignup(data);
      console.log(result);
      if(result){
        setLoading(false);
        router.push('/user/userdesboard')
      }
      
      } catch (err) {
        console.error(err);
      }
    },
  });

  return (

    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">


      <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8">
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Create an Account</h2>
        <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>


          <div>
            <label className="block text-gray-700">Name</label>
            <input
              type="text"
              name="name"
              placeholder="Your full name"
              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.name && formik.errors.name && (
              <div className="text-rose-700">{formik.errors.name}</div>
            )}
          </div>

          <div>
            <label className="block text-gray-700">Height</label>
            <input
              type="text"
              name="height"
              placeholder="Your Height"
              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.height}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.height && formik.errors.height && (
              <div className="text-rose-700">{formik.errors.height}</div>
            )}
          </div>
          <div>
            <label className="block text-gray-700">Weight</label>
            <input
              type="text"
              name="weight"
              placeholder="Your weight"
              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.weight}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.weight && formik.errors.weight && (
              <div className="text-rose-700">{formik.errors.weight}</div>
            )}
          </div>
          
         


          <div>
            <label className="block text-gray-700">Gender</label>
            <fieldset className=' text-gray-800'
            id="gender"
            name='gender'
            label="One of these please"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            value={formik.values.gender}
          > <input
              type="radio"
              name="gender"
              id="radioOption1"
              label="Choose this option"
              value="Male"
            />
            Male
            <input
              type="radio"
              name="gender"
              id="radioOption2"
              label="Or choose this one"
              value="Female"
            />
            Female
          </fieldset>
            {formik.touched.gender && formik.errors.gender && (
              <div className="text-rose-700">{formik.errors.gender}</div>
            )}
        
            </div>

          <div>
            <label className="block text-gray-700">Email</label>
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.email && formik.errors.email && (
              <div className="text-rose-700">{formik.errors.email}</div>
            )}
          </div>
          <div>
            <label className="block text-gray-700">Password</label>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Your password"
              className="mt-1 w-full px-4 py-2  text-gray-800 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            /><span onClick={myFunction} className='text-gray-800'>show</span>
            {formik.touched.password && formik.errors.password && (
              <div className="text-rose-700">{formik.errors.password}</div>
            )}
          </div>

          <div>
            <label className="block text-gray-700">Confirm Password</label>
            <input
              type="password"
              name="confirm_password"
              placeholder="Confirm password"
              className="mt-1 w-full px-4 py-2 text-gray-800 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formik.values.confirm_password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.confirm_password && formik.errors.confirm_password && (
              <div className="text-rose-700">{formik.errors.confirm_password}</div>
            )}
          </div>

          <button
            type="submit"
            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800"
          >
            {loading ? "submiting" : "Submite"}
          </button>

        </form>
      </div>

    </div>
  );
}

export default SignupForm;
