'use client'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import { ScheduleworkoutListing } from '@/app/apis/page';
import { useEffect, useState } from 'react'
import { NaveBar } from '@/app/navbar'
import Link from 'next/link'

export default function DemoApp() {

    const[events,SetEvent]=useState([])
    let aray=[];
    const fetchada= async()=>{
        let data= await ScheduleworkoutListing()
        console.log(data);
        
        data.data.map((exercise)=> {
            aray.push({title:exercise.name,start:exercise.date})
        })        
        SetEvent(aray)      ;  
    }
    useEffect(()=>{
        fetchada()
    },[])


  return (
    <div>
        <NaveBar/>
       <Link
                      href="/user/scheduleworkout"
                      className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
                    >
                      Schedule WorkOut
                    </Link>
      <FullCalendar
        plugins={[dayGridPlugin]}
        initialView='dayGridMonth'
        weekends={false}
        events={events}
        eventContent={renderEventContent}
      />
    </div>
  )
}

// a custom render function
function renderEventContent(eventInfo) {
  return (
    <><center>
      <h3><b>{eventInfo.event.title} </b></h3>
      </center>
    </>
  )
}