'use client'
import { NaveBar } from "@/app/navbar";
import { HistoryWorkoutData } from "@/app/apis/page";
import { useEffect, useState } from "react";
export default function WorkOutHistoryData(){
    const[workout,SetWorkout]=useState([]);

    const fetchData= async()=>{
        let data=await HistoryWorkoutData();
        SetWorkout(data.data);
    }
    useEffect(()=>{
        fetchData();
    },[])
    return(
        <div>
            <NaveBar/>
           
            <div className="flex-1 flex flex-col items-center justify-start px-4 py-8">
      <div className="max-w-6xl w-full bg-white rounded-2xl shadow-lg p-6 text-gray-900 text-base">
        <h2 className="text-3xl font-extrabold mb-6 text-center text-black">Exercise Listing</h2>
  
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto border-collapse border border-gray-300">
            <thead className="bg-gray-300 text-black text-base font-semibold">
              <tr>
                <th className="border border-gray-400 px-4 py-3 text-left">#</th>
                <th className="border border-gray-400 px-4 py-3 text-left"> Exercise Name</th>
                <th className="border border-gray-400 px-4 py-3 text-left">Sets</th>
                <th className="border border-gray-400 px-4 py-3 text-left">Reps</th>
                <th className="border border-gray-400 px-4 py-3 text-left">Date</th>
              
              </tr>
            </thead>
            <tbody>
              {workout.length > 0 ? (
                workout.map((user, index) => (
                  <tr key={user.id} className="hover:bg-gray-100">
                    <td className="border border-gray-300 px-4 py-3 text-gray-900">{user.id}</td>
                    <td className="border border-gray-300 px-4 py-3 text-gray-900">{user.exercise_name}</td>
                   
                    <td className="border border-gray-300 px-4 py-3 capitalize text-gray-900">{user.sets}</td>
                    <td className="border border-gray-300 px-4 py-3 capitalize text-gray-900">{user.reps}</td>
                    <td className="border border-gray-300 px-4 py-3 capitalize text-gray-900">{user.date}</td>


                   
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center py-4 text-gray-600 font-medium">No Exercise found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
    )
}