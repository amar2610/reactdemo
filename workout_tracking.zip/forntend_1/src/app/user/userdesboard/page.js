'use client'

import { ExerciseListing } from '@/app/apis/page'
import { useEffect, useState } from 'react'
import Link from 'next/link';
import { NaveBar } from '@/app/navbar';
export default function Home() {


const [items,setItem]=useState([]);
const getExercise =async()=>{
    let response = await ExerciseListing();
    let responseData=JSON.parse(response);
    setItem(responseData.data);
    console.log(responseData);
    
}
 
useEffect(()=>{
    getExercise();
},[])





  return (
  
    <div>
      <NaveBar/>
    <h1 className="text-3xl font-semibold mb-6 text-center ">Exercise Listing</h1>
  
  
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {
        items.map((product, idx) => (
          <div
            key={idx}
            className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 p-6 flex flex-col justify-between"
          >

            <center>
            <Link className="flex justify-center mb-4"   href={`/user/setexercise/${product.name}`} >
              <h3 className="text-xl font-semibold justify-center  text-gray-900 mb-2 h-48 w-full object-contain rounded-md">{product.name}</h3>
            </Link>
            </center>

          </div>
        ))}
    </div>
  </div>
  
  )
}
