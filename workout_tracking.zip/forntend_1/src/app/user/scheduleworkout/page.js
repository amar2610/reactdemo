'use client'

import { useEffect, useState } from "react";
import { useParams } from 'next/navigation';
import { useRouter } from "next/navigation";
import { Scheduleworkout } from "@/app/apis/page";
import { NaveBar } from "@/app/navbar";
export  default   function SetExercise() {
  const route=useRouter();
const [exercise,SetExercise]=useState(0);
const [day,SetDay]=useState(0);

const  submitdata= async()=>{
  let data={
    "name":exercise,
    "date":day,
  }
let response = await Scheduleworkout(data)
if(response){
  route.push('/user/calandar');
}
}

  return (
    <div>
      <NaveBar/>

      <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
     
     
           <div className="max-w-md w-full bg-white mb-100  rounded-2xl shadow-lg p-10">
            <form>
             <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">schedule Your WorkOut</h2>
     
               <div>
                 <label className="block text-gray-700 ">Exercise Name</label>
                 <input
                   type="text"
                   name="name"
                   onChange={(e)=>SetExercise(e.target.value)}
                   placeholder="Enter workout name"
                   className="mt-1 w-full px-4  mb-6 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                 />
                 
               </div>
               <div>
                 <label className="block text-gray-700 ">Exercise Date</label>
                 <input
                   type="date"
                   name="date"
                   onChange={(e)=>SetDay(e.target.value)}

                   placeholder="Enter workout date"
                   className="mt-1 w-full px-4  mb-6 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                 />
                 
               </div>
     
               <button
                 type="button"
                 onClick={()=> submitdata()}
                 className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800"
               >
                  Submit
               </button>
     
               </form>
           </div>
     
         </div>
  </div>
  
  )
}
