'use client'

import { useEffect, useState } from "react";
import { useParams } from 'next/navigation';
import { useRouter } from "next/navigation";
import { SetExercisedata } from "@/app/apis/page";
import { NaveBar } from "@/app/navbar";
export  default   function SetExercise() {
  const { id} = useParams()
  const route=useRouter();
const [Sets,SetSets]=useState(0);
const [Reps,SetReps]=useState(0);
const [weight,SetWeight]=useState(0);
console.log(Sets,Reps,weight);

const  submitdata= async()=>{
  let data={
    "exercise_name":id,
    "sets":Sets,
    "reps":Reps,
    "weight":weight
  }
let response = await SetExercisedata(data);
if(response){
  route.push('/user/userdesboard');
}
}

  return (
    <div>
      <NaveBar/>
      <form action="POST">
    <h1 className="text-3xl font-semibold mb-6 text-center "> Complete Exercise </h1>
      {
      
          <div
            className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 p-6 flex flex-col justify-between"
          >

  
            <div className="flex justify-center mb-4">
              <h3 className="text-xl font-semibold text-gray-900 mb-2 ">{id}</h3>
            </div>
            <div>
            <label className="block text-gray-700">Sets</label>
            <input
              type="number"
              name="Sets"
              placeholder="Enter your Sets"
              onChange={(e)=>SetSets(e.target.value)}
              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
            
            />
           
          </div>

          <div>
            <label className="block text-gray-700">Reps</label>
            <input
              type="number"
              name="height"
              placeholder="Enter Your Remp"
              onChange={(e)=>SetReps(e.target.value)}

              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
             required
            />
           
          </div>
          <div>
            <label className="block text-gray-700">Weight</label>
            <input
              type="text"
              name="weight"
              placeholder="Your weight"
              onChange={(e)=>SetWeight(e.target.value)}

              className="mt-1 w-full px-4 text-gray-800 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
             required
            />
           
          </div>
  
            <div className="mt-auto flex justify-center">
              <button className="bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors duration-300"
              type='button'
              onClick={()=>submitdata()}
              >
                Submite
              </button>
             
            </div>
          

          </div>
}
  </form>
  </div>
  
  )
}
