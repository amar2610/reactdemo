'use client'
import { useEffect, useState } from "react";
import { WorkoutData } from "@/app/apis/page";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { NaveBar } from "@/app/navbar";

export default function ChartProgress() {
  const [data, setData] = useState([]);

  const exerciseData= async()=>{
let response=await  WorkoutData();
setData(response.data)
  }
  useEffect(()=>{
    exerciseData();
  },[])

  return (
    <div>
        {<NaveBar/>}
    <div className="mt-6">
    <h1 className="text-3xl font-semibold mb-6 text-center ">Exercise Listing</h1>
  
  
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      <h2 className="text-3xl font-semibold mb-6 text-center ">Volume Progress (Reps × Sets)</h2>
      <LineChart width={1200} height={600} data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip  labelStyle={{color:"#ef4444"} } contentStyle={{background:'#000'}}/>
        <Line  type="monotone" dataKey="volume" stroke="#4ade80" />
      </LineChart>
    </div>
    </div>
    </div>
  );
}