import { encryptPlain, decryptPlain } from "../assests/encrypt";

export async function userSignup(data) {

    let response = encryptPlain(JSON.stringify(data))

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("Content-Type", "text/plain");


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/user/signup", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);
    localStorage.setItem("token", responsedata.data.token);
    localStorage.setItem("role", 'user')

    return responsedata;


}
export async function userLogin(data) {
    console.log(data);
    
    let response = encryptPlain(JSON.stringify(data))

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("Content-Type", "text/plain");


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/user/login", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);
   

    return responsedata;


}
export async function ExerciseListing() {
    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };

    let result = await fetch("http://localhost:3035/v1/user/exerciselisting", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    return decryptedResult;
}
export async function UserListing() {
    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };

    let result = await fetch("http://localhost:3035/v1/admin/userlisting", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    return decryptedResult;
}
export async function WorkoutData() {
    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };

    let result = await fetch("http://localhost:3035/v1/user/deailyworkout", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    return JSON.parse(decryptedResult);
}
export async function SetExercisedata(data) {

    let response = encryptPlain(JSON.stringify(data))

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/user/addexercisedetails", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function AdduserExercise(data) {

    let response = encryptPlain(JSON.stringify(data))

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/user/addexercise", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function HistoryWorkoutData() {
    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };

    let result = await fetch("http://localhost:3035/v1/user/getworkouthistory", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    return JSON.parse(decryptedResult);
}
export async function Scheduleworkout(data) {
    console.log(data);

    let response = encryptPlain(JSON.stringify(data))

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/user/scheduleworkout", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function ScheduleworkoutListing() {

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/user/scheduleworkoutlisting", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function foradminuserworkoutListing() {

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };



    let result = await fetch("http://localhost:3035/v1/admin/userworkoutlisting", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function DeleteUserWorkout(data) {

    let response = encryptPlain(JSON.stringify(data))

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };
    let result = await fetch("http://localhost:3035/v1/admin/deleteworkout", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function AddNewWorkout(data) {

    let response = encryptPlain(JSON.stringify(data))

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };
    let result = await fetch("http://localhost:3035/v1/admin/addworkout", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function AdminWorkoutlisting() {


    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };
    let result = await fetch("http://localhost:3035/v1/admin/workoutlisting", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}
export async function DeleteDefaultworkout(data) {

    let response = encryptPlain(JSON.stringify(data))

    const token = localStorage.getItem('token');
    console.log(token);

    if (!token) throw new Error("Token not found");

    const myHeaders = new Headers();
    myHeaders.append("api-key", "e15ce44fb22ed063b1ff4fcd0147aa7a");
    myHeaders.append("token", encryptPlain(token));
    myHeaders.append("Content-Type", "text/plain");

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: response,
        redirect: "follow"
    };
    let result = await fetch("http://localhost:3035/v1/admin/deletedefaultworkout", requestOptions);
    const encryptedResult = await result.text();

    const decryptedResult = decryptPlain(encryptedResult);
    let responsedata = JSON.parse(decryptedResult);


    return responsedata;


}