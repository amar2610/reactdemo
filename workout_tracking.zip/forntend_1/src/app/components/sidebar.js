'use client'
import Link from 'next/link';
import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function Sidebar() {
  const [open, setOpen] = useState(true);
    const route=useRouter();
      const logout=()=>{
        document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        document.cookie = "role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        localStorage.removeItem("token");
        localStorage.removeItem("role");
  
  
        route.push('/')
  
      }

  return (
    <div className="flex">
      <div className={`bg-gray-800 text-white h-screen p-4 transition-all duration-300 ${open ? 'w-64' : 'w-16'}`}>
        <button onClick={() => setOpen(!open)} className="mb-6">
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
        <ul className="space-y-4">
          <li>
            <Link href="/admin/desboard" className="flex items-center gap-2 hover:text-gray-300">
              📊 {open && 'Dashboard'}
            </Link>
          </li>
          <li>
            <Link href="/admin/addworkout" className="flex items-center gap-2 hover:text-gray-300">
              👥 {open && 'Add WorkOut'}
            </Link>
          </li>
          <li>
            <Link href="/admin/userlisting" className="flex items-center gap-2 hover:text-gray-300">
              👥 {open && 'Users'}
            </Link>
          </li>
          <li>
            <Link href="/admin/userworkoutlisting" className="flex items-center gap-2 hover:text-gray-300">
              👥 {open && ' User WorkOut Listing'}
            </Link>
          </li>
          <li>
            <Link href="/admin/workoutlisting" className="flex items-center gap-2 hover:text-gray-300">
              👥 {open && 'Workout Listing'}
            </Link>
          </li>
          <li>
            <button onClick={()=>logout()} className="flex items-center gap-2 hover:text-gray-300">
              👥 {open && 'Logout'}
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
}
