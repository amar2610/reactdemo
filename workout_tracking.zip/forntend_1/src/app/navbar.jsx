  'use client';
  import Link from 'next/link';
import { useRouter } from 'next/navigation';
  export function NaveBar() {

    const route=useRouter();
    const logoutUser=()=>{
      document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      document.cookie = "role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      localStorage.removeItem("token");
      localStorage.removeItem("role");


      route.push('/')

    }
    return (
      <nav className="bg-gray-800">
        <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
          <div className="relative flex h-16 items-center justify-between">
            <div className="flex items-center">
              <img
                className="h-8 w-auto"
                src="https://tailwindcss.com/plus-assets/img/logos/mark.svg?color=indigo&shade=500"
                alt="Your Company"
              />
            </div>

            <div className="hidden sm:flex sm:ml-6 space-x-4">
              <Link
                href="/user/userdesboard"
                className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                Dashboard
              </Link>
              <Link
                href="/user/workoutchart"
                className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                My Progress
              </Link>
              <Link
                href="/user/addexercise"
                className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                Add Own WorkOut
              </Link>
              <Link
                href="/user/calandar"
                className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                Calandar
              </Link>
              <Link
                href="/user/workouthistory"
                className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                History
              </Link>
              <button
               onClick={()=>logoutUser()}
                className="rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>
    );
  }
