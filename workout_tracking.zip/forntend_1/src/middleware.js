import { NextResponse } from 'next/server'

export function middleware(request) {
  const token = request.cookies.get('token')?.value || '';
  const role = request.cookies.get('role')?.value || '';
const path=request.nextUrl.pathname
let array=path.split('/')
console.log(array);


  if (!token) {
    return NextResponse.redirect(new URL('/', request.url));
  }
  else if( array[1]=='admin' && role=='user'){
    if(token){
      return NextResponse.redirect(new URL('/user/userdesboard', request.url));
    }else{
      return NextResponse.redirect(new URL('/', request.url));

    }}
  else if( array[1]=='user' && role=='admin'){
    if(token){
      return NextResponse.redirect(new URL('/admin/desboard', request.url));
    }else{
      return NextResponse.redirect(new URL('/', request.url));

    }
  }

  return NextResponse.next();
}

export const config = {
  matcher:[ '/admin/:path*','/user/:path*']
  
}
