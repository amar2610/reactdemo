import { useEffect, useState } from 'react';
import './App.css';
import SignupForm from './components/form/formcomponent';

function App() {
  let theam= JSON.parse(localStorage.getItem('theam') || false);
  const [darkMode, setDarkMode] = useState(theam);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem("theam",darkMode);
     
    } else {
      root.classList.remove('dark');
      localStorage.setItem("theam",darkMode);
    }
  }, [darkMode]);

  return (
    <div className='dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white'>
      <button
        onClick={() => setDarkMode(!darkMode)}
      >
        Toggle {darkMode ? 'Light' : 'Dark'} Mode
      </button>

      <SignupForm />
    </div>
  );
}

export default App;
