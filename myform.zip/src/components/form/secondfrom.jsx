function SecondForm(props){
  const setback=()=>{
    setTimeout(()=>{
        window.location.reload();
    },2000)
   
  };
    return(

          <form  className="space-y-4" noValidate>
        
        
                                <div>
                                    <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">FullName</label>
                                    <input
                                       
                                        className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                        readOnly
                                        value={props.data.name}
                                       
                                    />
                                 
                                </div>
        
        
                                <div>
                                    <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">User_id</label>
                                    <input
                                        readOnly
                                        value={props.data.userId}
                                        className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                    />
                                  
                                </div>
                                <button
                               
                                className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800"
                                onClick={()=>{setback()}}
                                >Submite</button>
                               
                            </form>
    )
}
export default SecondForm
