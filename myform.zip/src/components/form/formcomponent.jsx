import React, { useState } from 'react';
import { useFormik } from 'formik';
import { ColorRing } from 'react-loader-spinner'
import * as Yup from 'yup';
import  disposableEmailDetector  from '../../assests/index.json'
import SecondForm from '../form/secondfrom';
function SignupForm() {
    const [hide, setHide] = useState(false);
    const [loading, setLoading] = useState(false);
    const [userdata, setUserData] = useState({});
    const [passwordStrength, SetPasswordStrength] = useState();
    const[suggest,setsuggest]=useState(false);
    const domain=['gmal.com','yahoo.com','outlook.com'];
    const [makeemail,setEmail]=useState();
   
 
    const myFunction = () => {

        let x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    };
    const formatenumber=(number)=>{
        let num="";
        
          
            for(let i=0;i<number.length;i++){
                console.log(number[i])
                if(i===3 || i===6 ||i===9){
                    
                    num=num+'-'+number[i];
                   
                }else{
                    num=num+number[i];
                }
            }
            return num
        
        
    }
    const check = (password) => {
        const hasLowercase = /[a-z]/.test(password);
        const hasUppercase = /[A-Z]/.test(password);
        const hasDigit = /\d/.test(password);
        const hasSpecialChar = /[@$!%*?&]/.test(password);

        const trueCount = [hasLowercase, hasUppercase, hasDigit, hasSpecialChar].filter(Boolean).length;
        if (password.length === 0) {
            SetPasswordStrength("")

        }
        else if (trueCount === 4) {
            SetPasswordStrength("Strong")


        }
        else if (trueCount >= 2) {
            SetPasswordStrength("Moderate")


        } else {
            SetPasswordStrength("Weak")


        }
    }


  

    const formik = useFormik({
        initialValues: {
            name: '',
            email: '',
            age: '',
            password: '',
            type: '',
            company: '',
            number: '',
            businessemail: '',
            confirm_password: '',
            terms: false,
        },
      

        validationSchema: Yup.object({
            name: Yup.string().trim().required("Name is required"),
            email: Yup.string().trim().email("Enter a valid email").required("Email is required"),
            type: Yup.string().trim().required("set account type"),
            businessemail: Yup.string().when('type', {
                is: 'business',
                then: () => Yup.string().email('Invalid Email')
                    .notOneOf([Yup.ref('email')], 'Business Email Must Be Different From Personal Email')
                    .required('Business Email Is Required'),
                otherwise: () => Yup.string().notRequired()
            }),
            company: Yup.string().when('type', {
                is: 'business',
                then: () => Yup.string().required('Company Name Is Required'),
                otherwise: () => Yup.string().notRequired()
            }),
            number: Yup.string().when('type', {
                is: 'business',
                then: () => Yup.string().required('VAT Number Is Required').min(15,'minimum 15 characters required'),
                otherwise: () => Yup.string().notRequired()
            }),
            password: Yup.string().min(8, 'Minimum 8 characters required').min(8, 'Password must be 8 characters long')
                .matches(/[0-9]/, 'Password requires a number')
                .matches(/[a-z]/, 'Password requires a lowercase letter')
                .matches(/[A-Z]/, 'Password requires an uppercase letter')
                .matches(/[^\w]/, 'Password requires a symbol').required('Password Is Required'),
            confirm_password: Yup.string()
                .oneOf([Yup.ref("password"), null], "Password and confirm-password shoud be same")
                .required("Confirm password is required"),
                
            terms: Yup.bool()
                .oneOf([true], "You must accept the terms and conditions")
                .required("Required")
        }),
        
       

        validate:async (values) => {
            let errors={}
            check(values.password)
            if(values.number){
                formatenumber(values.number) ;
            }

          

            if(values.businessemail.includes('@')){
                setsuggest(true)
            }
            const isDisposableEmail = (email) => {
                const domain = email.split("@")[1];
                return disposableEmailDetector.includes(domain);
              };
              
              // Usage in validation
              if (isDisposableEmail(values.email)) {
                errors.email = 'Disposable emails not allowed';
              }
              return errors
          
        },
        

        onSubmit: async () => {
            setLoading(true);
            try {
                const x = Math.floor(Math.random() * 10 + 1);
                setUserData({userId:x,name:formik.values.name});
                setUserData.UserName=formik.values.name;
               
                setTimeout(() => {
                      setHide(true);
                    setLoading(false);
                }, 2000);

            } catch (err) {
                console.error(err);
            }
        },
    });

    return (
        <div className=''>
        <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 bg-white dark:bg-gray-900 text-black dark:text-white">
            {!hide ?
                
                <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">
                    <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Create an Account</h2>
                    <form onSubmit={formik.handleSubmit} className="space-y-4" noValidate>

                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">FullName</label>
                            <input
                                type="text"
                                name="name"
                                placeholder="Your full name"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.name}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.name && formik.errors.name && (
                                <div className="text-rose-700">{formik.errors.name}</div>
                            )}
                        </div>
                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Email</label>
                            <input
                                type="email"
                                name="email"
                                placeholder="Your Email"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.email}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.email && formik.errors.email && (
                                <div className="text-rose-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">{formik.errors.email}</div>
                            )}
                        </div>
                        <div>
                            <label  className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Account Type</label>
                            <select name="type" value={formik.values.type}
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            >
                                <option value="">----Select Account Type---</option>
                                <option value="personal">Personal</option>
                                <option value="business">Business</option>
                            </select>
                            {formik.values.type === "business" && (
                                <>
                                    <div>
                                        <label className="block text-gray-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Company_Name</label>
                                        <input
                                            type="text"
                                            name="company"
                                            id="company"
                                            placeholder="Your company name"
                                            className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500   dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                            value={formik.values.company}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                        />
                                        {formik.touched.company && formik.errors.company && (
                                            <div className="text-rose-700">{formik.errors.company}</div>
                                        )}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Business_Email</label>
                                        <input
                                            type="eamil"
                                            name="businessemail"
                                            placeholder="enter your business email"
                                            className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                            value={formik.values.businessemail}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                        />
                                       {suggest && (
                                                <div className="domain-suggestions mt-1 border-1 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">
                                                    {domain.map((domain) => (
                                                        <div className="domain-suggestion mt-1 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white" onClick={() => {
                                                            const email = formik.values.businessemail.split('@')[0];
                                                            formik.setFieldValue('businessemail', `${email}@${domain}`);
                                                            setsuggest(false);
                                                        }}>
                                                            {domain}
                                                        </div>
                                                    ))}
                                                </div>
                                        )}
                                        
                                        {formik.touched.businessemail && formik.errors.businessemail && (
                                            <div className="text-rose-700">{formik.errors.businessemail}</div>
                                        )}
                                         
                                    </div>
                                    
                                  
                                    <div>
                                        <label className="block text-gray-700  dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Vat-Number</label>
                                        <input
                                            type="text"
                                            name="number"
                                            placeholder="enter vat number"
                                            className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                            value={formik.values.number}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                        />
                                        {formik.touched.number && formik.errors.number && (
                                            <div className="text-rose-700">{formik.errors.number}</div>
                                        )}
                                    </div>
                                </>

                            )}

                            {formik.touched.type && formik.errors.type && (
                                <div className="text-rose-700">{formik.errors.type}</div>
                            )}
                        </div>


                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Password</label>
                            <input
                                type="password"
                                name="password"
                                id="password"
                                placeholder="Your password"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.password}
                                onChange={(e) => { formik.handleChange(e) }}
                                onBlur={formik.handleBlur}
                            /><button id="togglePassword" type="button" className="absolute   px-1 py-3 text-blue-600 hover:text-blue-600" onClick={myFunction}>👁️</button>

                            {formik.touched.password && formik.errors.password && (
                                <div className="text-rose-700">{formik.errors.password}</div>
                            )}
                            <span >{passwordStrength}</span>
                        </div>
                        <div>

                        </div>

                        <div>
                            <label className="block text-gray-700 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white">Confirm Password</label>
                            <input
                                type="password"
                                name="confirm_password"
                                placeholder="Confirm password"
                                className="mt-1 w-full px-4 py-2 border rounded-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-zinx-800 dark:bg-gray-900 text-black dark:text-white"
                                value={formik.values.confirm_password}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                            {formik.touched.confirm_password && formik.errors.confirm_password && (
                                <div className="text-rose-700">{formik.errors.confirm_password}</div>
                            )}
                        </div>


                        <div>
                            <label className="flex items-center space-x-2">
                                <input
                                    type="checkbox"
                                    name="terms"
                                    checked={formik.values.terms}
                                    onChange={formik.handleChange}
                                    onBlur={formik.handleBlur}
                                    className="border-gray-300 focus:outline-none focus:ring-blue-500"
                                />
                                <span>I agree to the Terms & Conditions</span>
                            </label>
                            {formik.touched.terms && formik.errors.terms && (
                                <div className="text-rose-700">{formik.errors.terms}</div>
                            )}
                        </div>


                        <button
                            type="submit"
                            className="w-full text-white py-2 rounded-lg transition-all bg-blue-700 hover:bg-blue-800 disabled:bg-blue-200 disabled:cursor-not-allowed"
                            disabled={!formik.dirty || !formik.isValid}
                        >
                            {loading ? (<center> <ColorRing
                                visible={true}
                                height="40"
                                width="90"
                                ariaLabel="color-ring-loading"
                                wrapperStyle={{}}
                                wrapperClass="color-ring-wrapper"
                                colors={['#fff', '#fff', '#fff', '#fff', '#fff']}
                            /></center>) : "Submite"}
                        </button>

                    </form>
                </div>
                 :<SecondForm data={userdata}/>}
        </div>
        </div>
    );
}

export default SignupForm;
