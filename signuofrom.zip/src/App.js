import logo from './logo.svg';
import './App.css';
import SignupForm from './components/from/formcomponent';
function App() {
  return (
    <div className="">
     <SignupForm/>
    </div>
  );
}

export default App;
