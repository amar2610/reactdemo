import React, { useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';

function SignupForm() {

    const [error, setErrors] = useState({});
    const [success, setsuccess] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        password: '',
        confirm_password: ''
    });

    /*------------------------------- Validation -------------------*/
    const validation = () => {
        const errorvalidation = {};
        // for name
        if (!formData.name.trim()) {
            errorvalidation.name = "name is required";
        } else if (formData.name.trim().length < 3) {
            errorvalidation.name = "enter name  more than 3 character";
        }
        else if ((/\d/).test(formData.name.trim())) {
            errorvalidation.name = "Name Can not Contaion number";
        }
        // for email
        if (!formData.email.trim()) {
            errorvalidation.email = "email is required";

        } else if (!(/^[^\s@]+@[^\s@]+\.[^\s@]+$/).test(formData.email.trim())) {
            errorvalidation.email = "enter valid email";
        }
        //for password
        if (!formData.password.trim()) {
            errorvalidation.password = "password is required";
        }
        else if (formData.password.trim().length < 8) {
            errorvalidation.password = "password contains at least 8 characters";
        }
        else if (!(/\d/).test(formData.password)) {
            errorvalidation.password = "password contains at least one number";
        } else if ((/[%/|}{)( ]/).test(formData.password)) {
            errorvalidation.password = "password  can not contains %, /, | & brackets";
        }
        else if (!(/[$#@*]/).test(formData.password)) {
            errorvalidation.password = "password contains at least one special character ";
        }
        else if (!(/@/).test(formData.password)) {
            errorvalidation.password = "password contains at least one @";
        }
        else if (!(/[A-Z]/).test(formData.password)) {
            errorvalidation.password = "password contains at least one capital character ";
        }
        // confirm-password
        if (!formData.confirm_password.trim()) {
            errorvalidation.confirm_password = "confirm password is required";
        } else if (formData.password.trim() !== formData.confirm_password.trim()) {
            errorvalidation.confirm_password = " password and confirm password  shoud be same";
        }
        // for phone
        if (formData.phone.trim()) {
            console.log(formData.phone.trim());

            if (formData.phone.trim().length !== 10) {
                errorvalidation.phone = "phone number can not be less than  or more than 10 number ";
            } else if (!(/^\d+$/).test(formData.phone.trim())) {
                errorvalidation.phone = "phone number can not be contain character";

            }
        }

        return errorvalidation
    }

    const handleChange = (e) => {
        setFormData((prev) => ({
            ...prev,
            [e.target.name]: e.target.value
        }));

       // setErrors({})
        setErrors({
            ...error,
            [e.target.name]: " ",
        });
    };


    const resetvalue=()=>{
        setFormData({
            name: '',
            email: '',
            phone: '',
            password: '',
            confirm_password: ''
        });
        setErrors({})
        setsuccess(false)
    }
    const setbutton = () => {
        let array = Object.values(error);
        const isOnlyEmptyValues = array.every(item => item.trim() === "");
        console.log(isOnlyEmptyValues);
        return isOnlyEmptyValues
    }
  

    const handleSubmit = (e) => {
        e.preventDefault();
        let validationError = validation();
        if (Object.keys(validationError).length === 0) {
            setsuccess(true);
            setFormData({
                name: '',
                email: '',
                phone: '',
                password: '',
                confirm_password: ''
            })
            setErrors({})
             toast("Signup Successfuly!")

        }
        else {
            setsuccess(false)
            setErrors(validationError);
        }
    };


    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
            <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8">
               
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Create an Account</h2>
                <form onSubmit={handleSubmit} noValidate className="space-y-4">
                    <div>
                        <label className="block text-gray-700">Name</label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            
                            className={`mt-1 ${error.name ? 'border-red-500 focus:ring-red-500 '
                             : 'border-gray-300  focus:outline-none focus:ring-blue-500'} w-full px-4 py-2 border rounded-lg  focus:ring-2 focus:ring-blue-500`}
                            placeholder="Your full name"
                        />
                        {error.name && <span className='my-4... text-rose-600'>{error.name}</span>
                        }
                    </div>
                    <div>
                        <label className="block text-gray-700">Email</label>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className={`mt-1 ${error.email ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'} w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500`}
                            placeholder="you@example.com"
                            
                        />
                        {error.email && <span className='my-4... text-rose-600'>{error.email}</span>
                        }
                    </div>
                    <div>
                        <label className="block text-gray-700">Phone</label>
                        <input
                            type="text"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className={`mt-1 ${error.phone ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'} w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800`}
                            placeholder="enter your phone number"
                        />
                        {error.phone && <span className='my-4... text-rose-600'>{error.phone}</span>
                        }
                    </div>

                    <div>
                        <label className="block text-gray-700">Password</label>
                        <input
                            type="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            className={`mt-1 ${error.password ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'} w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500`}
                            placeholder="Enter a strong password"
                        />
                        {error.password && <span className='my-4... text-rose-600'>{error.password}</span>
                        }
                    </div>
                    <div>
                        <label className="block text-gray-700">Co-Password</label>
                        <input
                            type="password"
                            name="confirm_password"
                            value={formData.confirm_password}
                            onChange={handleChange}
                            className={`mt-1 ${error.confirm_password ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'} w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500`}
                            placeholder="Enter a strong password"

                        />
                        {error.confirm_password && <span className='my-4... text-rose-600'>{error.confirm_password}</span>
                        }
                    </div>
                    <button
                        type="submit"
                        className="w-full text-white py-2 rounded-lg transition-all 
                                      bg-blue-700 hover:bg-blue-800 
                                      disabled:bg-blue-200 disabled:cursor-not-allowed"
                        disabled={!setbutton()}
                    >
                        Sign Up
                    </button>
                    <button type='button'
                     onClick= {resetvalue}
                        className="w-full text-white py-2 rounded-lg transition-all 
                                      bg-rose-700 hover:bg-rose-800 
                                   ">Reset</button>
                 {<ToastContainer />}
                </form>
               
            </div>
        </div>
    );
}

export default SignupForm;
