function MyTitle(){
        return(
            <h1> Increment & Decrement The Number</h1>
        )
    }
export default MyTitle;