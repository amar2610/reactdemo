import UserCard from "./usercard";

function UserData() {
    const userdatas = [
        { name: "Amar Sinh", surname: "Rathod", age: 22, address: "G-30 Kalpana Nagar" },
        { name: "Rishabh", surname: "Upadhayay", age: 22, address: "Naroda Gam" },
        { name: "Parth", surname: "Mevada", age: 22, address: "Tragad" },
        { name: "Jatin", surname: "Chandel", age: 22, address: "Surat" }
    ];
    return (
        <div>
            {userdatas.map((u) => (
                <UserCard userCard={u} />
            ))}
        </div>
    );
}

export default UserData;
