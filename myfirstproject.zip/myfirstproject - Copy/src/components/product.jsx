import ProductCard from "./productcard";
function ProductData() {
    const products = [
        {
          id: 1,
          name: "Wireless Headphones",
          price: 2999,
          description: "High-quality wireless headphones with noise cancellation.",
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqSHZXmpJbUDBLnJgjwtBt4Blce2VYSReWdA&s"
        },
        {
          id: 2,
          name: "Smart Watch",
          price: 4999,
          description: "Track your fitness, sleep, and notifications on the go.",
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQx0vLWpMO4yNv6IrH6kCMib4Z3xj3PYR0OCA&s"
        },
        {
          id: 3,
          name: "Gaming Mouse",
          price: 1499,
          description: "Ergonomic mouse with customizable buttons and RGB lighting.",
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSk6HM5H8BNuFKl9aLra4eH-XTCXC6u7ETG6Q&s"
        },
        {
          id: 4,
          name: "Bluetooth Speaker",
          price: 1999,
          description: "Portable Bluetooth speaker with deep bass and clear sound.",
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqGRof0WJGbSn_JNg2dDLSmZyU6_VR6DAUuQ&s"
        }
      ];
      
    return (
        <div>
            {products.map((u) => (
                <ProductCard productsinfo={u} />
            ))}
        </div>
    );
}

export default ProductData;
