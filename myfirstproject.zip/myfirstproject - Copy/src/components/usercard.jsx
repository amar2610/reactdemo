import { useState } from "react";
const UserCard = (props)=>{
    let [show, setShow] = useState(false)
    console.log(props);
    

    return (
        <div style={{
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: '16px',
            margin: '10px',
            width: '300px',
            height:"200px",
            boxShadow: '5px 5px 8px rgba(0,0,0,0.1)',
            backgroundColor: '#fff',
            float: 'left',
            textAlign: 'center'
        }}>
            <h3 style={{ margin: '0 0 8px 0', color: '#333' }}>{props.userCard.name}</h3>
            <p style={{ margin: '4px 0', color: '#666' }}>surname: {props.userCard.surname}</p>
            
            <button style={{margin:'4px 0',marginTop:'10px',border:'none',padding:'10px',fontSize:'1.2rem', backgroundColor:'blue', color:'white', borderRadius:'4px'}} onClick={()=>{setShow(!show)}}>{show ? 'Hide Details' : 'More Details'}</button>
        {show && (
            <>
                <p style={{margin: '4px 0', color: '#666' }}>Age: {props.userCard.age}</p>
                <p id="address" style={{ margin: '4px 0', color: '#666' }}>Address: {props.userCard.address}</p>
            </>
        )}
        </div>
    );
}

export default UserCard