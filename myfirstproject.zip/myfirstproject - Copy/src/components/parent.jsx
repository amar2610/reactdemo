import Child from "./child";
import { useState } from 'react';

function Parent() {
    const [name, setName] = useState("");

    let setnames=()=>{
        let nameis=  document.getElementById('name').value;
        setName(nameis)
   }
return(
   <div className="App">
   <input type="text" id="name"></input>
   <button onClick={setnames}>submit</button>
   <Child name={name}/>
</div>
)
}

export default Parent;
