import { useState } from "react";

function ProductCard( product ){
    console.log(product);
    
    const [show, setShow] = useState(false);

    return (
        <div style={{
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: '16px',
            margin: '10px',
            width: '300px',
            boxShadow: '5px 5px 8px rgba(0,0,0,0.1)',
            backgroundColor: '#fff',
            float: 'left',
            textAlign: 'center'
        }}>
            <img 
                src={product.productsinfo.image} 
                alt={product.productsinfo.name} 
                style={{ width: 'auto', height: 'auto', objectFit: 'cover', borderRadius: '8px' }}
            />
            <h3 style={{ margin: '10px 0 8px 0', color: '#333' }}>{product.productsinfo.name}</h3>
            <p style={{ margin: '4px 0', color: '#666' }}>₹{product.productsinfo.price}</p>

            <button 
                style={{
                    margin: '10px 0',
                    border: 'none',
                    padding: '10px',
                    fontSize: '1rem',
                    backgroundColor: 'blue',
                    color: 'white',
                    borderRadius: '4px',
                    cursor: 'pointer'
                }}
                onClick={() => setShow(!show)}
            >
                {show ? 'Hide Details' : 'More Details'}
            </button>

            {show && (
                <p style={{ margin: '4px 0', color: '#444' }}>{product.productsinfo.description}</p>
            )}
        </div>
    );
};

export default ProductCard;
