import './App.css';
import { useState } from 'react';
import MyTitle from'./components/mycomponents';
import Parent from './components/parent';
import UserData from './components/userdata';
import ProductData from './components/product';

function App() {
   let [number,updatenumber]= useState(0);
  return (
    <div className="App">
      <MyTitle/>
     <h1>{number}</h1>
     <button onClick={()=>updatenumber(number+1)}>increment</button>
     <button onClick={()=>updatenumber(number-1)}>decrement</button>
     <Parent/>
    <UserData/>
    <ProductData/>
    </div>
  );
}

export default App;
